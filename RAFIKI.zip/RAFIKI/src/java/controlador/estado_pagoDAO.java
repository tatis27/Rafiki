package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import modelo.estado_pago;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class estado_pagoDAO {
    
    //Adicionar 
    //conexion a la base de datos 
    
    public String adicionarestado_pago(estado_pago estado_pago) {
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
    //sentecia     
        PreparedStatement sentencia;
    //try-catch   
        try {
    // consulta         
            String Query = "INSERT INTO estado_pago (tipoestado_pago)"
                    + "VALUES (?)";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,estado_pago.getTipoestado_pago());
            
            sentencia.execute();
            miRespuesta = "";
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un problea en estado_pagoDAO\n " + ex.getMessage());
        }
        
        return miRespuesta;
    }
    
    //Actualizar 
    
    public String actualizaestado_pago(estado_pago estado_pago){
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try {
            String Query = "update estado_pago set tipoestado_pago=? where idestado_pago=?";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,estado_pago.getTipoestado_pago());
            sentencia.setInt(2, estado_pago.getIdestado_pago());
            
            sentencia.executeUpdate();
            miRespuesta = "";
            
        } catch (Exception ex) {
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en estado_pagoDAO\n" + ex.getMessage());
        }
        return miRespuesta;
    }
    
    // consultar 
    
   public estado_pago Consultarestado_pago (int idestado_pago) {
       estado_pago miestado_pago = null;
       // establecemos las variables de la comunicacion con la base de datos 
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn();
       
       // se recibe u  parametro de consulta idestado_pago para poder recuerar la información 
       
       try {
           Statement sentencia = nuevaCon.createStatement();
        // Definir el orden de busqueda de las columnas para la consulta 

            String Query = "SELECT idestado_pago, tipoestado_pago FROM estado_pago WHERE idestado_pago=" + idestado_pago;
            ResultSet rs = sentencia.executeQuery(Query);
        while (rs.next()) {
            miestado_pago = new estado_pago();
            miestado_pago.setIdestado_pago(rs.getInt(1));
            miestado_pago.setTipoestado_pago(rs.getString(2));
        }
        return miestado_pago;
       }catch (Exception ex) {
           System.out.println(ex.getMessage());
           return miestado_pago;
       }
   }

    public ArrayList<estado_pago> ConsultarListadoestado_pago(String criterio) throws SQLException {
       ArrayList<estado_pago> milistadosestado_pago = new ArrayList<estado_pago>();
       estado_pago miestado_pago;
       
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn();
       
       try {
           Statement sentencia = nuevaCon.createStatement ();
           String Query = " SELECT idestado_pago, tipoestado_pago " + "  FROM estado_pago where tipoestado_pago like '%"+ criterio +"%' ORDER BY idestado_pago;";
           ResultSet rs = sentencia.executeQuery(Query);
           while (rs.next()) {
               
               miestado_pago = new estado_pago();
               miestado_pago.setIdestado_pago(rs.getInt(1));
               miestado_pago.setTipoestado_pago(rs.getString(2));
               milistadosestado_pago.add(miestado_pago);
           }
           return milistadosestado_pago;
       }catch (Exception ex) {
           System.out.println("Error consulta listado de Estado de pagos:" + ex.getMessage());
           return milistadosestado_pago;
       }
       
   }
   
   // Eliminar 
   
   public String Eliminarestado_pago(estado_pago estado_pago) {
       String miRespuesta;
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn ();
       
       PreparedStatement sentencia;
       try {
           String Query = " DELETE FROM estado_pago where idestado_pago=? and tipoestado_pago=? ;";
           sentencia = nuevaCon.prepareStatement(Query);
           sentencia.setInt(1, estado_pago.getIdestado_pago());
           sentencia.setString(2, estado_pago.getTipoestado_pago());
           
           sentencia.execute();
           miRespuesta = "";
           
       } catch (Exception ex) {
           miRespuesta = ex.getMessage();
           System.err.println("Ocurrio un error en estado_pagoDAO.Eliminarestado_pago" + ex.getMessage());
       }
       return miRespuesta;
   }
 
}
