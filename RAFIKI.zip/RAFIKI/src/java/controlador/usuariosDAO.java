
package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import modelo.Usuarios;


public class usuariosDAO {
    
    //Adicionar 
    //conexion a la base de datos 
    
    public String usuarios(Usuarios usuarios) {
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
    //sentecia     
        PreparedStatement sentencia;
    //try-catch   
        try {
    // consulta         
            String Query = "INSERT INTO usuarios (nombres,apellidos,telefono,email,contrasena,idroles,idtipo_documento) "
                    + " VALUES (?,?,?,?,?,?,?)";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,usuarios.getNombres());
            sentencia.setString(2,usuarios.getApellidos());
            sentencia.setString(3,usuarios.getTelefono());
            sentencia.setString(4,usuarios.getEmail());
            sentencia.setString(5,usuarios.getContrasena());
            sentencia.setInt(6,usuarios.getIdroles());
            sentencia.setInt(7,usuarios.getIdtipo_documento());
         
            
            sentencia.execute();
            miRespuesta = "";
            
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un problea en usuariosDAO\n " + ex.getMessage());
        }
        
        return miRespuesta;
    }
    
    //Actualizar 
    
    public String actualizarusuarios (Usuarios usuarios){
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try {
            String Query = "update usuarios set nombres=?, apellidos=?, telefono=?, email=?, contrasena=?, idroles=? where idusuarios=?";
           sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,usuarios.getNombres());
            sentencia.setString(2,usuarios.getApellidos());
            sentencia.setString(3,usuarios.getTelefono());
            sentencia.setString(4,usuarios.getEmail());
            sentencia.setString(5,usuarios.getContrasena());
            sentencia.setInt(6,usuarios.getIdroles());
            sentencia.setInt(7,usuarios.getIdtipo_documento());
          
            
            sentencia.executeUpdate();
            miRespuesta = "";
            
        } catch (Exception ex) {
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en usuarioDAO\n" + ex.getMessage());
        }
        return miRespuesta;
    }
    
    // Consultar
    
    public Usuarios consultarusuarios(int idusuarios) {
       Usuarios miusuarios = null;
       
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        try {
            Statement sentencia = nuevaCon.createStatement();
            String Query = "select idusuarios, nombres, apellidos, telefono, email, contrasena, idroles, idtipo_documento from usuarios where idusuarios ="+ idusuarios;
            ResultSet rs = sentencia.executeQuery(Query);
            while (rs.next()) {
                miusuarios = new Usuarios ();
                miusuarios.setIdusuarios(rs.getInt(1));
                miusuarios.setNombres(rs.getString(2));
                miusuarios.setApellidos(rs.getString(3));
                miusuarios.setTelefono(rs.getString(4));
                miusuarios.setEmail(rs.getString(5));
                miusuarios.setContrasena(rs.getString(6));
                miusuarios.setIdroles(rs.getInt(7));
                miusuarios.setIdtipo_documento(rs.getInt(8));
                
            }
            return miusuarios;
        }catch (Exception ex) {
            System.out.println(ex.getMessage());
            return miusuarios;
        }
   }
    
    public ArrayList<Usuarios> ConsultarListadousuarios(String criterio) throws SQLException {
       ArrayList<Usuarios> milistadosusuarios = new ArrayList<Usuarios>();
       Usuarios miusuarios;
       
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn();
       
       try {
           Statement sentencia = nuevaCon.createStatement ();
           String Query = " SELECT idusuarios, nombres, apellidos, telefono, email, contrasena, idroles, idtipo_documento " + "  FROM usuarios where idtipo_documento like '%"+ criterio +"%' ORDER BY idusuarios;";
           ResultSet rs = sentencia.executeQuery(Query);
           while (rs.next()) {
               
               miusuarios = new  Usuarios();
               miusuarios.setIdusuarios(rs.getInt(1));
               miusuarios.setNombres(rs.getString(2));
               miusuarios.setApellidos(rs.getString(3));
               miusuarios.setTelefono(rs.getString(4));
               miusuarios.setEmail(rs.getString(5));
               miusuarios.setContrasena(rs.getString(6));
               miusuarios.setIdroles(rs.getInt(7));
               miusuarios.setIdtipo_documento(rs.getInt(8));
              
               
               milistadosusuarios.add(miusuarios);
           }
           return milistadosusuarios;
       }catch (Exception ex) {
           System.out.println("Error consulta listado de roles:" + ex.getMessage());
           return milistadosusuarios;
       }
       
   }
   
   // Eliminar 
   
    public String Eliminarusuarios(Usuarios usuarios) {
       String miRespuesta;
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn ();
       
       PreparedStatement sentencia;
       try {
           String Query = " DELETE FROM usuarios where idusuarios=? and nombres=? and apellidos=? and telefono=? and email=? and contrasena=? and idroles=? and idtipo_documento=?";
           sentencia = nuevaCon.prepareStatement(Query);
           sentencia.setInt(1, usuarios.getIdusuarios());
           sentencia.setString(2, usuarios.getNombres());
           sentencia.setString(3, usuarios.getApellidos());
           sentencia.setString(4, usuarios.getTelefono());
           sentencia.setString(5, usuarios.getEmail());
           sentencia.setString(6, usuarios.getContrasena());
           sentencia.setInt(7, usuarios.getIdroles());
           sentencia.setInt(8, usuarios.getIdtipo_documento());
           
           sentencia.execute();
           miRespuesta = "";
           
       } catch (Exception ex) {
           miRespuesta = ex.getMessage();
           System.err.println("Ocurrio un error en usuariosDAO.Eliminarusuarios" + ex.getMessage());
       }
       return miRespuesta;
   }
   
}




