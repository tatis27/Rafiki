//
package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import modelo.tipo_documento;

public class tipo_documentoDAO {
    
    //Adicionar 
    //conexion a la base de datos 
    
    public String adicionartipo_documento(tipo_documento tipo_documento) {
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
    //sentecia     
        PreparedStatement sentencia;
    //try-catch   
        try {
    // consulta         
            String Query = "INSERT INTO tipo_documento (tipo_documento)"
                    + "VALUES (?)";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,tipo_documento.getTipo_documento());
            
            sentencia.execute();
            miRespuesta = "";
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un problea en tipo_documentoDAO\n " + ex.getMessage());
        }
        
        return miRespuesta;
    }
    
    //Actualizar 
    
    public String actualizartipo_documento (tipo_documento tipo_documento){
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try {
            String Query = "update tipo_documento set tipo_documento=? where idtipo_documento=?";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,tipo_documento.getTipo_documento());
            sentencia.setInt(2,tipo_documento.getIdtipo_documento());
            
            sentencia.executeUpdate();
            miRespuesta = "";
            
        } catch (Exception ex) {
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en tipo_documentoDAO\n" + ex.getMessage());
        }
        return miRespuesta;
    }
    
    // Consultar
    
    public tipo_documento consultartipo_documento (int idtipo_documento) {
       tipo_documento mitipo_documento = null;
       
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        try {
            Statement sentencia = nuevaCon.createStatement();
            String Query = "select idtipo_documento, tipo_documento from tipo_documento where idtipo_documento ="+ idtipo_documento;
            ResultSet rs = sentencia.executeQuery(Query);
            while (rs.next()) {
                mitipo_documento = new tipo_documento ();
                mitipo_documento.setIdtipo_documento(rs.getInt(1));
                mitipo_documento.setTipo_documento(rs.getString(2));
                
                
            }
            return mitipo_documento;
        }catch (Exception ex) {
            System.out.println(ex.getMessage());
            return mitipo_documento;
        }
   }
    
    public ArrayList<tipo_documento> ConsultarListadotipo_documento(String criterio) throws SQLException {
       ArrayList<tipo_documento> milistadostipo_documento = new ArrayList<tipo_documento>();
       tipo_documento mitipo_documento;
       
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn();
       
       try {
           Statement sentencia = nuevaCon.createStatement ();
           String Query = " SELECT idtipo_documento, tipo_documento " + "  FROM tipo_documento where tipo_documento like '%"+ criterio +"%' ORDER BY idtipo_documento;";
           ResultSet rs = sentencia.executeQuery(Query);
           while (rs.next()) {
               
               mitipo_documento = new tipo_documento();
               mitipo_documento.setIdtipo_documento(rs.getInt(1));
               mitipo_documento.setTipo_documento(rs.getString(2));
               
               milistadostipo_documento.add(mitipo_documento);
           }
           return milistadostipo_documento;
       }catch (Exception ex) {
           System.out.println("Error consulta listado de tipo documento:" + ex.getMessage());
           return milistadostipo_documento;
       }
       
   }
   
   // Eliminar 
   
    public String Eliminartipo_documento(tipo_documento tipo_documento) {
       String miRespuesta;
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn ();
       
       PreparedStatement sentencia;
       try {
           String Query = " DELETE FROM tipo_documento where idtipo_documento=? and tipo_documento=?";
           sentencia = nuevaCon.prepareStatement(Query);
           sentencia.setInt(1, tipo_documento.getIdtipo_documento());
           sentencia.setString(2, tipo_documento.getTipo_documento());
          
           
           sentencia.execute();
           miRespuesta = "";
           
       } catch (Exception ex) {
           miRespuesta = ex.getMessage();
           System.err.println("Ocurrio un error en tipo_documentoDAO.Eliminartipo_documento" + ex.getMessage());
       }
       return miRespuesta;
   }
   
}

