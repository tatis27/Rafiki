
package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import modelo.actividades_adicionales;

public class actividades_adicionalesDAO {
    
    //Adicionar 
    //conexion a la base de datos 
    
    public String adicionaractividades_adicionales(actividades_adicionales actividades_adicionales) {
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
    //sentecia     
        PreparedStatement sentencia;
    //try-catch   
        try {
    // consulta         
            String Query = "INSERT INTO actividades_adicionales (nombre,idubicacion)"
                    + "VALUES (?,?)";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,actividades_adicionales.getNombre());
            sentencia.setInt(2,actividades_adicionales.getIdubicacion());
            
            sentencia.execute();
            miRespuesta = "";
            
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un problea en actividades_adicionalesDAO\n " + ex.getMessage());
        }
        
        return miRespuesta;
    }
    
    //Actualizar 
    
    public String actualizaractividades_adicionales (actividades_adicionales actividades_adicionales){
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try {
            String Query = "update actividades_adicionales set nombre=?, idubicacion=? where idactividades_adicionales=?";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,actividades_adicionales.getNombre());
            sentencia.setInt(2,actividades_adicionales.getIdubicacion());
            sentencia.setInt(3,actividades_adicionales.getIdactividades_adicionales());
          
            
            sentencia.executeUpdate();
            miRespuesta = "";
            
        } catch (Exception ex) {
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en actividades_adicionalesDAO\n" + ex.getMessage());
        }
        return miRespuesta;
    }
    
    // consutar 
    
     public actividades_adicionales consultaractividades_adicionales (int idactividades_adicionales) {
       actividades_adicionales miactividades_adicionales = null;
       
       Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        try {
            Statement sentencia = nuevaCon.createStatement();
            String Query = "select idactividades_adicionales, nombre, idubicacion from actividades_adicionales where idactividades_adicionales ="+ idactividades_adicionales;
            ResultSet rs = sentencia.executeQuery(Query);
            while (rs.next()) {
                miactividades_adicionales = new actividades_adicionales ();
                miactividades_adicionales.setIdactividades_adicionales(rs.getInt(1));
                miactividades_adicionales.setNombre(rs.getString(2));
                miactividades_adicionales.setIdubicacion(rs.getInt(3));
            }
            return miactividades_adicionales;
        }catch (Exception ex) {
            System.out.println(ex.getMessage());
            return miactividades_adicionales;
        }
   }
     
     public ArrayList<actividades_adicionales> ConsultarListadoactividades_adicionales(String criterio) throws SQLException {
       ArrayList<actividades_adicionales> milistadosactividades_adicionales = new ArrayList<actividades_adicionales>();
       actividades_adicionales miactividades_adicionales;
       
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn();
       
       try {
           Statement sentencia = nuevaCon.createStatement ();
           String Query = " SELECT idactividades_adicionales, nombre, idubicacion " + "  FROM actividades_adicionales where nombre like '%"+ criterio +"%' ORDER BY idactividades_adicionales;";
           ResultSet rs = sentencia.executeQuery(Query);
           while (rs.next()) {
               
               miactividades_adicionales = new actividades_adicionales();
               miactividades_adicionales.setIdactividades_adicionales(rs.getInt(1));
               miactividades_adicionales.setNombre(rs.getString(2));
               miactividades_adicionales.setIdubicacion(rs.getInt(3));
               milistadosactividades_adicionales.add(miactividades_adicionales);
           }
           return milistadosactividades_adicionales;
       }catch (Exception ex) {
           System.out.println("Error consulta listado de actividades adicionales:" + ex.getMessage());
           return milistadosactividades_adicionales;
       }
       
   }
     
     
     // Eliminar 
   
   public String Eliminaractividades_adicionales(actividades_adicionales actividades_adicionales) {
       String miRespuesta;
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn ();
       
       PreparedStatement sentencia;
       try {
           String Query = " DELETE FROM actividades_adicionales where idactividades_adicionales=? and nombre=? and idubicacion=?;";
           sentencia = nuevaCon.prepareStatement(Query);
           sentencia.setInt(1, actividades_adicionales.getIdactividades_adicionales());
           sentencia.setString(2, actividades_adicionales.getNombre());
           sentencia.setInt(3, actividades_adicionales.getIdubicacion());
           
           sentencia.execute();
           miRespuesta = "";
           
       } catch (Exception ex) {
           miRespuesta = ex.getMessage();
           System.err.println("Ocurrio un error en actividades_adicionalesDAO.Eliminaractividades_adicionales" + ex.getMessage());
       }
       return miRespuesta;
   }
   
}


