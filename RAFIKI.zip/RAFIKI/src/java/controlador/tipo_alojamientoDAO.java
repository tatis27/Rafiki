package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import modelo.tipo_alojamiento;

public class tipo_alojamientoDAO {
    
    //Adicionar 
    //conexion a la base de datos 
    
    public String adicionartipo_alojamiento(tipo_alojamiento tipo_alojamiento) {
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
    //sentecia     
        PreparedStatement sentencia;
    //try-catch   
        try {
    // consulta         
            String Query = "INSERT INTO tipo_alojamiento (tipo_alojamiento)"
                    + "VALUES (?)";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,tipo_alojamiento.getTipo_alojamiento());
            
            sentencia.execute();
            miRespuesta = "";
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un problea en tipo_alojamientoDAO\n " + ex.getMessage());
        }
        
        return miRespuesta;
    }
    
    //Actualizar 
    
    public String actualizartipo_alojamiento (tipo_alojamiento tipo_alojamiento){
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try {
            String Query = "update tipo_alojamiento set tipo_alojamiento=? where idtipo_alojamiento=?";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,tipo_alojamiento.getTipo_alojamiento());
            sentencia.setInt(2, tipo_alojamiento.getIdtipo_alojamiento());
            
            sentencia.executeUpdate();
            miRespuesta = "";
            
        } catch (Exception ex) {
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en rolesDAO\n" + ex.getMessage());
        }
        return miRespuesta;
    }
    
     // Consultar 
    
   public tipo_alojamiento consultartipo_alojamiento(int idtipo_alojamiento) {
       tipo_alojamiento mitipo_alojamiento = null;
       
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        try {
            Statement sentencia = nuevaCon.createStatement();
            String Query = "select idtipo_alojamiento, tipo_alojamiento from tipo_alojamiento where idtipo_alojamiento ="+ idtipo_alojamiento;
            ResultSet rs = sentencia.executeQuery(Query);
            while (rs.next()) {
                mitipo_alojamiento = new tipo_alojamiento ();
                mitipo_alojamiento.setIdtipo_alojamiento(rs.getInt(1));
                mitipo_alojamiento.setTipo_alojamiento(rs.getString(2));
            }
            return mitipo_alojamiento;
        }catch (Exception ex) {
            System.out.println(ex.getMessage());
            return mitipo_alojamiento;
        }
   }
   
   public ArrayList<tipo_alojamiento> ConsultarListadotipo_alojamiento(String criterio) throws SQLException {
       ArrayList<tipo_alojamiento> milistadostipo_alojamiento = new ArrayList<tipo_alojamiento>();
       tipo_alojamiento mitipo_alojamiento;
       
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn();
       
       try {
           Statement sentencia = nuevaCon.createStatement ();
           String Query = " SELECT idtipo_alojamiento, tipo_alojamiento " + "  FROM tipo_alojamiento where tipo_alojamiento like '%"+ criterio +"%' ORDER BY idtipo_alojamiento;";
           ResultSet rs = sentencia.executeQuery(Query);
           while (rs.next()) {
               
               mitipo_alojamiento = new tipo_alojamiento();
               mitipo_alojamiento.setIdtipo_alojamiento(rs.getInt(1));
               mitipo_alojamiento.setTipo_alojamiento(rs.getString(2));
               milistadostipo_alojamiento.add(mitipo_alojamiento);
           }
           return milistadostipo_alojamiento;
       }catch (Exception ex) {
           System.out.println("Error consulta listado de tipo de alojamiento:" + ex.getMessage());
           return milistadostipo_alojamiento;
       }
       
   }
   
   // Eliminar 
   
   public String Eliminartipo_alojamiento(tipo_alojamiento tipo_alojamiento) {
       String miRespuesta;
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn ();
       
       PreparedStatement sentencia;
       try {
           String Query = " DELETE FROM tipo_alojamiento where idtipo_alojamiento=? and tipo_alojamiento=?";
           sentencia = nuevaCon.prepareStatement(Query);
           sentencia.setInt(1, tipo_alojamiento.getIdtipo_alojamiento());
           sentencia.setString(2, tipo_alojamiento.getTipo_alojamiento());
           
           sentencia.execute();
           miRespuesta = "";
           
       } catch (Exception ex) {
           miRespuesta = ex.getMessage();
           System.err.println("Ocurrio un error en tipo_alojamientoDAO.Eliminartipo_alojamiento" + ex.getMessage());
       }
       return miRespuesta;
   }
   
}

