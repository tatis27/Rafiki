
package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import modelo.roles;

public class rolesDAO {
    
    //Adicionar 
    //conexion a la base de datos 
    
    public String adicionarroles(roles roles) {
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
    //sentecia     
        PreparedStatement sentencia;
    //try-catch   
        try {
    // consulta         
            String Query = "INSERT INTO roles (nombre)"
                    + "VALUES (?)";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,roles.getNombre());
            
            sentencia.execute();
            miRespuesta = "";
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un problea en rolesDAO\n " + ex.getMessage());
        }
        
        return miRespuesta;
    }
    
    //Actualizar 
    
    public String actualizarroles (roles roles){
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try {
            String Query = "update roles set nombre=? where idroles=?";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,roles.getNombre());
            sentencia.setInt(2, roles.getIdroles());
            
            sentencia.executeUpdate();
            miRespuesta = "";
            
        } catch (Exception ex) {
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en rolesDAO\n" + ex.getMessage());
        }
        return miRespuesta;
    }
    
    // Consultar
    
    public roles consultarroles (int idroles) {
       roles miroles = null;
       
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        try {
            Statement sentencia = nuevaCon.createStatement();
            String Query = "select idroles, nombre from roles where idroles ="+ idroles;
            ResultSet rs = sentencia.executeQuery(Query);
            while (rs.next()) {
                miroles = new roles ();
                miroles.setIdroles(rs.getInt(1));
                miroles.setNombre(rs.getString(2));
                
                
            }
            return miroles;
        }catch (Exception ex) {
            System.out.println(ex.getMessage());
            return miroles;
        }
   }
    
    public ArrayList<roles> ConsultarListadoroles(String criterio) throws SQLException {
       ArrayList<roles> milistadosroles = new ArrayList<roles>();
       roles miroles;
       
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn();
       
       try {
           Statement sentencia = nuevaCon.createStatement ();
           String Query = " SELECT idroles, nombre " + "  FROM roles where nombre like '%"+ criterio +"%' ORDER BY idroles;";
           ResultSet rs = sentencia.executeQuery(Query);
           while (rs.next()) {
               
               miroles = new roles();
               miroles.setIdroles(rs.getInt(1));
               miroles.setNombre(rs.getString(2));
               
               milistadosroles.add(miroles);
           }
           return milistadosroles;
       }catch (Exception ex) {
           System.out.println("Error consulta listado de roles:" + ex.getMessage());
           return milistadosroles;
       }
       
   }
   
   // Eliminar 
   
    public String Eliminarroles(roles roles) {
       String miRespuesta;
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn ();
       
       PreparedStatement sentencia;
       try {
           String Query = " DELETE FROM roles where idroles=? and nombre=?";
           sentencia = nuevaCon.prepareStatement(Query);
           sentencia.setInt(1, roles.getIdroles());
           sentencia.setString(2, roles.getNombre());
          
           
           sentencia.execute();
           miRespuesta = "";
           
       } catch (Exception ex) {
           miRespuesta = ex.getMessage();
           System.err.println("Ocurrio un error en rolesDAO.Eliminarroles" + ex.getMessage());
       }
       return miRespuesta;
   }
   
}


