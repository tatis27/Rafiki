
package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import modelo.reservas;

public class reservasDAO {
    
    //Adicionar 
    //conexion a la base de datos 
    
    public String reservas(reservas reservas) {
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
    //sentecia     
        PreparedStatement sentencia;
    //try-catch   
        try {
    // consulta         
            String Query = "INSERT INTO reservas (fecha_inicio,fecha_final,fecha_estadoreserva,idusuarios,idestado_reserva,idpropiedades)"
                    + "VALUES (?,?,?,?,?,?)";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,reservas.getFecha_inicio());
            sentencia.setString(2,reservas.getFecha_final());
            sentencia.setString(3,reservas.getFecha_estadoreserva());
            sentencia.setInt(4,reservas.getIdusuarios());
            sentencia.setInt(5,reservas.getIdestado_reserva());
            sentencia.setInt(6,reservas.getIdpropiedades());
          
            
            sentencia.execute();
            miRespuesta = "";
            
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un problea en reservasDAO\n " + ex.getMessage());
        }
        
        return miRespuesta;
    }
    
    //Actualizar 
    
    public String actualizarreservas(reservas reservas){
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try {
            String Query = "update reservas set fecha_inicio=?, fecha_final=?, fecha_estadoreserva=?, idusuarios=?, idestado_reserva=?, idpropiedades=? where idreservas=?";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,reservas.getFecha_inicio());
            sentencia.setString(2,reservas.getFecha_final());
            sentencia.setString(3,reservas.getFecha_estadoreserva());
            sentencia.setInt(4,reservas.getIdusuarios());
            sentencia.setInt(5,reservas.getIdestado_reserva());
            sentencia.setInt(6,reservas.getIdpropiedades());
            sentencia.setInt(7,reservas.getIdreservas());
          
            
            sentencia.executeUpdate();
            miRespuesta = "";
            
        } catch (Exception ex) {
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en reservasDAO\n" + ex.getMessage());
        }
        return miRespuesta;
    }
    
    // Consultar
    
    public reservas consultarreservas (int idreservas) {
       reservas mireservas = null;
       
       Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        try {
            Statement sentencia = nuevaCon.createStatement();
            String Query = "select idreservas, fecha_inicio, fecha_final, fecha_estadoreserva, idusuarios, idestado_reserva, idpropiedades from reservas where idreservas ="+ idreservas;
            ResultSet rs = sentencia.executeQuery(Query);
            while (rs.next()) {
                mireservas = new reservas ();
                mireservas.setIdreservas(rs.getInt(1));
                mireservas.setFecha_inicio(rs.getString(2));
                mireservas.setFecha_final(rs.getString(3));
                mireservas.setFecha_estadoreserva(rs.getString(4));
                mireservas.setIdusuarios(rs.getInt(5));
                mireservas.setIdestado_reserva(rs.getInt(6));
                mireservas.setIdpropiedades(rs.getInt(7));
            }
            return mireservas;
        }catch (Exception ex) {
            System.out.println(ex.getMessage());
            return mireservas;
        }
   }
    
    public ArrayList<reservas> ConsultarListadoreservas(String criterio) throws SQLException {
       ArrayList<reservas> milistadosreservas = new ArrayList<reservas>();
       reservas mireservas;
       
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn();
       
       try {
           Statement sentencia = nuevaCon.createStatement ();
           String Query = " SELECT idreservas,fecha_inicio, fecha_final, fecha_estadoreserva, idusuarios, idestado_reserva, idpropiedades " + "  FROM reservas where idpropiedades like '%"+ criterio +"%' ORDER BY idreservas;";
           ResultSet rs = sentencia.executeQuery(Query);
           while (rs.next()) {
               
               mireservas = new reservas ();
               mireservas.setIdreservas(rs.getInt(1));
               mireservas.setFecha_inicio(rs.getString(2));
               mireservas.setFecha_final(rs.getString(3));
               mireservas.setFecha_estadoreserva(rs.getString(4));
               mireservas.setIdusuarios(rs.getInt(5));
               mireservas.setIdestado_reserva(rs.getInt(6));
               mireservas.setIdpropiedades(rs.getInt(7));
               milistadosreservas.add(mireservas);
           }
           return milistadosreservas;
       }catch (Exception ex) {
           System.out.println("Error consulta listado de reservas:" + ex.getMessage());
           return milistadosreservas;
       }
       
   }
   
   // Eliminar 
   
    public String Eliminarreservas(reservas reservas) {
       String miRespuesta;
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn ();
       
       PreparedStatement sentencia;
       try {
           String Query = " DELETE FROM reservas where idreservas=? and fecha_inicio=? and fecha_final=? and fecha_estadoreserva=? and idusuarios=? and idestado_reserva=? and idpropiedades=?";
           sentencia = nuevaCon.prepareStatement(Query);
           sentencia.setInt(1, reservas.getIdreservas());
           sentencia.setString(2, reservas.getFecha_inicio());
           sentencia.setString(3, reservas.getFecha_final());
           sentencia.setString(4, reservas.getFecha_estadoreserva());
           sentencia.setInt(5, reservas.getIdusuarios());
           sentencia.setInt(6, reservas.getIdestado_reserva());
           sentencia.setInt(7, reservas.getIdpropiedades());
           
           sentencia.execute();
           miRespuesta = "";
           
       } catch (Exception ex) {
           miRespuesta = ex.getMessage();
           System.err.println("Ocurrio un error en reservasDAO.Eliminarreservas" + ex.getMessage());
       }
       return miRespuesta;
   }
   
}



