package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import modelo.adjuntos;
import java.util.ArrayList;

public class adjuntosDAO {
    
    //Adicionar 
    //conexion a la base de datos 
    
    public String adicionaradjuntos(adjuntos adjuntos) {
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
    //sentecia     
        PreparedStatement sentencia;
    //try-catch   
        try {
    // consulta         
            String Query = "INSERT INTO adjuntos (tipo_archivo,ruta_archivo,descripcion,idpropiedades)"
                    + "VALUES (?,?,?,?)";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,adjuntos.getTipo_archivo());
            sentencia.setString(2,adjuntos.getRuta_archivo());
            sentencia.setString(3,adjuntos.getDescripcion());
            sentencia.setInt(4,adjuntos.getIdpropiedades());
            
            sentencia.execute();
            miRespuesta = "";
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un problea en adjuntosDAO\n " + ex.getMessage());
        }
        
        return miRespuesta;
    }
    
    //Actualizar 
    
    public String actualizaradjuntos (adjuntos adjuntos){
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try {
            String Query = "UPDATE adjuntos set tipo_archivo=?, ruta_archivo=?, descripcion=?, Idpropiedades=? where idadjuntos=?";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,adjuntos.getTipo_archivo());
            sentencia.setString(2,adjuntos.getRuta_archivo());
            sentencia.setString(3,adjuntos.getDescripcion());
            sentencia.setInt(4,adjuntos.getIdpropiedades());
            sentencia.setInt(5,adjuntos.getIdadjuntos());
            
            
            sentencia.executeUpdate();
            miRespuesta = "";
            
        } catch (Exception ex) {
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en adjuntosDAO\n" + ex.getMessage());
        }
        return miRespuesta;
    }
    
    // Consultar 
    
   public adjuntos consultaradjuntos (int idadjuntos) {
       adjuntos miadjuntos = null;
       
       Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        try {
            Statement sentencia = nuevaCon.createStatement();
            String Query = "select idadjuntos, tipo_archivo, ruta_archivo, descripcion, idpropiedades from adjuntos where idadjuntos ="+ idadjuntos;
            ResultSet rs = sentencia.executeQuery(Query);
            while (rs.next()) {
                miadjuntos = new adjuntos ();
                miadjuntos.setIdadjuntos(rs.getInt(1));
                miadjuntos.setTipo_archivo(rs.getString(2));
                miadjuntos.setRuta_archivo(rs.getString(3));
                miadjuntos.setDescripcion(rs.getString(4));
                miadjuntos.setIdpropiedades(rs.getInt(5));
            }
            return miadjuntos;
        }catch (Exception ex) {
            System.out.println(ex.getMessage());
            return miadjuntos;
        }
   }
   
   public ArrayList<adjuntos> ConsultarListadoadjuntos(String criterio) throws SQLException {
       ArrayList<adjuntos> milistadosadjuntos = new ArrayList<adjuntos>();
       adjuntos miadjuntos;
       
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn();
       
       try {
           Statement sentencia = nuevaCon.createStatement ();
           String Query = " SELECT idadjuntos, tipo_archivo, ruta_archivo, descripcion, idpropiedades " + "  FROM adjuntos where idpropiedades like '%"+ criterio +"%' ORDER BY idadjuntos;";
           ResultSet rs = sentencia.executeQuery(Query);
           while (rs.next()) {
               
               miadjuntos = new adjuntos();
               miadjuntos.setIdadjuntos(rs.getInt(1));
               miadjuntos.setTipo_archivo(rs.getString(2));
               miadjuntos.setRuta_archivo(rs.getString(3));
               miadjuntos.setDescripcion(rs.getString(4));
               miadjuntos.setIdpropiedades(rs.getInt(5));
               milistadosadjuntos.add(miadjuntos);
           }
           return milistadosadjuntos;
       }catch (Exception ex) {
           System.out.println("Error consulta listado de Adjuntos:" + ex.getMessage());
           return milistadosadjuntos;
       }
       
   }
   
   // Eliminar 
   
   public String Eliminaradjuntos(adjuntos adjuntos) {
       String miRespuesta;
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn ();
       
       PreparedStatement sentencia;
       try {
           String Query = " DELETE FROM adjuntos where idadjuntos=? and tipo_archivo=? and ruta_archivo=? and descripcion=? and idpropiedades=?;";
           sentencia = nuevaCon.prepareStatement(Query);
           sentencia.setInt(1, adjuntos.getIdadjuntos());
           sentencia.setString(2, adjuntos.getTipo_archivo());
           sentencia.setString(3, adjuntos.getRuta_archivo());
           sentencia.setString(4, adjuntos.getDescripcion());
           sentencia.setInt(5, adjuntos.getIdpropiedades());
           
           sentencia.execute();
           miRespuesta = "";
           
       } catch (Exception ex) {
           miRespuesta = ex.getMessage();
           System.err.println("Ocurrio un error en adjuntosDAO.Eliminaradjuntos" + ex.getMessage());
       }
       return miRespuesta;
   }
   
}
