package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import modelo.estado_reserva;

public class estado_reservaDAO {
    
    //Adicionar 
    //conexion a la base de datos 
    
    public String adicionarestado_reserva(estado_reserva estado_reserva) {
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
    //sentecia     
        PreparedStatement sentencia;
    //try-catch   
        try {
    // consulta         
            String Query = "INSERT INTO estado_reserva (tipoestado_reserva)"
                    + "VALUES (?)";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,estado_reserva.getTipoestado_reserva());
            
            sentencia.execute();
            miRespuesta = "";
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un problea en estado_reservaDAO\n " + ex.getMessage());
        }
        
        return miRespuesta;
    }
    
    //Actualizar 
    
    public String actualizarestado_reserva(estado_reserva estado_reserva){
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try {
            String Query = "update estado_reserva set tipoestado_reserva=? where idestado_reserva=?";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,estado_reserva.getTipoestado_reserva());
            sentencia.setInt(2, estado_reserva.getIdestado_reserva());
            
            sentencia.executeUpdate();
            miRespuesta = "";
            
        } catch (Exception ex) {
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en estado_reservaDAO\n" + ex.getMessage());
        }
        return miRespuesta;
    }
    
    // consultar 
    
   public estado_reserva Consultarestado_reserva (int idestado_reserva) {
       estado_reserva miestado_reserva = null;
       // establecemos las variables de la comunicacion con la base de datos 
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn();
       
       // se recibe u  parametro de consulta idestado_pago para poder recuerar la información 
       
       try {
           Statement sentencia = nuevaCon.createStatement();
        // Definir el orden de busqueda de las columnas para la consulta 

            String Query = "SELECT idestado_reserva, tipoestado_reserva FROM estado_reserva WHERE idestado_reserva=" + idestado_reserva;
            ResultSet rs = sentencia.executeQuery(Query);
        while (rs.next()) {
            miestado_reserva = new estado_reserva();
            miestado_reserva.setIdestado_reserva(rs.getInt(1));
            miestado_reserva.setTipoestado_reserva(rs.getString(2));
        }
        return miestado_reserva;
       }catch (Exception ex) {
           System.out.println(ex.getMessage());
           return miestado_reserva;
       }
   }

    public ArrayList<estado_reserva> ConsultarListadoestado_reserva(String criterio) throws SQLException {
       ArrayList<estado_reserva> milistadosestado_reserva = new ArrayList<estado_reserva>();
       estado_reserva miestado_reserva;
       
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn();
       
       try {
           Statement sentencia = nuevaCon.createStatement ();
           String Query = " SELECT idestado_reserva, tipoestado_reserva " + "  FROM estado_reserva where tipoestado_reserva like '%"+ criterio +"%' ORDER BY idestado_reserva;";
           ResultSet rs = sentencia.executeQuery(Query);
           while (rs.next()) {
               
               miestado_reserva = new estado_reserva();
               miestado_reserva.setIdestado_reserva(rs.getInt(1));
               miestado_reserva.setTipoestado_reserva(rs.getString(2));
               milistadosestado_reserva.add(miestado_reserva);
           }
           return milistadosestado_reserva;
       }catch (Exception ex) {
           System.out.println("Error consulta listado de Estado de pagos:" + ex.getMessage());
           return milistadosestado_reserva;
       }
       
   }
   
   // Eliminar 
   
   public String Eliminarestado_reserva(estado_reserva estado_reserva) {
       String miRespuesta;
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn ();
       
       PreparedStatement sentencia;
       try {
           String Query = " DELETE FROM estado_reserva where idestado_reserva=? and tipoestado_reserva=? ;";
           sentencia = nuevaCon.prepareStatement(Query);
           sentencia.setInt(1, estado_reserva.getIdestado_reserva());
           sentencia.setString(2, estado_reserva.getTipoestado_reserva());
           
           sentencia.execute();
           miRespuesta = "";
           
       } catch (Exception ex) {
           miRespuesta = ex.getMessage();
           System.err.println("Ocurrio un error en estado_reservaDAO.Eliminarestado_reserva" + ex.getMessage());
       }
       return miRespuesta;
   }
 
}

