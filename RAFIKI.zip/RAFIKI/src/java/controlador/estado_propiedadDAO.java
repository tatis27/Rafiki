package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import modelo.estado_propiedad;

public class estado_propiedadDAO {
    
    //Adicionar 
    //conexion a la base de datos 
    
    public String adicionarestado_propiedad(estado_propiedad estado_propiedad) {
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
    //sentecia     
        PreparedStatement sentencia;
    //try-catch   
        try {
    // consulta         
            String Query = "INSERT INTO estado_propiedad (tipoestado_propiedad)"
                    + "VALUES (?)";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,estado_propiedad.getTipoestado_propiedad());
            
            sentencia.execute();
            miRespuesta = "";
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un problea en estado_propiedadDAO\n " + ex.getMessage());
        }
        
        return miRespuesta;
    }
    
    //Actualizar 
    
    public String actualizarestado_propiedad (estado_propiedad estado_propiedad){
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try {
            String Query = "update estado_propiedad set tipoestado_propiedad=? where idestado_propiedad=?";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,estado_propiedad.getTipoestado_propiedad());
            sentencia.setInt(2, estado_propiedad.getIdestado_propiedad());
            
            sentencia.executeUpdate();
            miRespuesta = "";
            
        } catch (Exception ex) {
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en estado_propiedadDAO\n" + ex.getMessage());
        }
        return miRespuesta;
    }
    
    // consultar
    
   public estado_propiedad consultarestado_propiedad (int idestado_propiedad) {
       estado_propiedad miestado_propiedad = null;
       
       Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        try {
            Statement sentencia = nuevaCon.createStatement();
            String Query = "select idestado_propiedad, tipoestado_propiedad from estado_propiedad where idestado_propiedad ="+ idestado_propiedad;
            ResultSet rs = sentencia.executeQuery(Query);
            while (rs.next()) {
                miestado_propiedad = new estado_propiedad ();
                miestado_propiedad.setIdestado_propiedad(rs.getInt(1));
                miestado_propiedad.setTipoestado_propiedad(rs.getString(2));
            }
            return miestado_propiedad;
        }catch (Exception ex) {
            System.out.println(ex.getMessage());
            return miestado_propiedad;
        }
   }
   
   public ArrayList<estado_propiedad> ConsultarListadoestado_propiedad(String criterio) throws SQLException {
       ArrayList<estado_propiedad> milistadosestado_propiedad = new ArrayList<estado_propiedad>();
       estado_propiedad miestado_propiedad;
       
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn();
       
       try {
           Statement sentencia = nuevaCon.createStatement ();
           String Query = " SELECT idestado_propiedad, tipoestado_propiedad " + "  FROM estado_propiedad where tipoestado_propiedad like '%"+ criterio +"%' ORDER BY idestado_propiedad;";
           ResultSet rs = sentencia.executeQuery(Query);
           while (rs.next()) {
               
               miestado_propiedad = new estado_propiedad();
               miestado_propiedad.setIdestado_propiedad(rs.getInt(1));
               miestado_propiedad.setTipoestado_propiedad(rs.getString(2));
               milistadosestado_propiedad.add(miestado_propiedad);
           }
           return milistadosestado_propiedad;
       }catch (Exception ex) {
           System.out.println("Error consulta listado de Estado de Propiedad:" + ex.getMessage());
           return milistadosestado_propiedad;
       }
       
   }
   
   // Eliminar 
   
   public String Eliminarestado_propiedad(estado_propiedad estado_propiedad) {
       String miRespuesta;
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn ();
       
       PreparedStatement sentencia;
       try {
           String Query = " DELETE FROM estado_propiedad where idestado_propiedad=? and tipoestado_propiedad=? ;";
           sentencia = nuevaCon.prepareStatement(Query);
           sentencia.setInt(1, estado_propiedad.getIdestado_propiedad());
           sentencia.setString(2, estado_propiedad.getTipoestado_propiedad());
           
           sentencia.execute();
           miRespuesta = "";
           
       } catch (Exception ex) {
           miRespuesta = ex.getMessage();
           System.err.println("Ocurrio un error en estado_propiedadDAO.Eliminarestado_propiedad" + ex.getMessage());
       }
       return miRespuesta;
   }
 
}
