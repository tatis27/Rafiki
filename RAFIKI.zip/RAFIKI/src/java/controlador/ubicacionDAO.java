
package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import modelo.ubicacion;
import java.util.ArrayList;

public class ubicacionDAO {
    
    //Adicionar 
    //conexion a la base de datos 
    
    public String adicionarubicacion(ubicacion ubicacion) {
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
    //sentecia     
        PreparedStatement sentencia;
    //try-catch   
        try {
    // consulta         
            String Query = "INSERT INTO ubicacion (Departamento,municipio)"
                    + "VALUES (?,?)";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,ubicacion.getDepartamento());
            sentencia.setString(2,ubicacion.getMunicipio());
            
            sentencia.execute();
            miRespuesta = "";
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un problea en ubicacionDAO\n " + ex.getMessage());
        }
        
        return miRespuesta;
    }
    
    //Actualizar 
    
    public String actualizarubicacion (ubicacion ubicacion){
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try {
            String Query = "update ubicacion set departamento=?, municipio=? where idubicacion=?";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,ubicacion.getDepartamento());
            sentencia.setString(2,ubicacion.getMunicipio());
            sentencia.setInt(3, ubicacion.getIdubicacion());
            
            sentencia.executeUpdate();
            miRespuesta = "";
            
        } catch (Exception ex) {
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en ubicacionDAO\n" + ex.getMessage());
        }
        return miRespuesta;
    }
    
    // Consultar 
    
   public ubicacion consultarubicion (int idubicacion) {
       ubicacion miubicacion = null;
       
       Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        try {
            Statement sentencia = nuevaCon.createStatement();
            String Query = "select idubicacion, departamento, municipio from ubicacion where idubicacion ="+ idubicacion;
            ResultSet rs = sentencia.executeQuery(Query);
            while (rs.next()) {
                miubicacion = new ubicacion ();
                miubicacion.setIdubicacion(rs.getInt(1));
                miubicacion.setDepartamento(rs.getString(2));
                miubicacion.setMunicipio(rs.getString(3));
            }
            return miubicacion;
        }catch (Exception ex) {
            System.out.println(ex.getMessage());
            return miubicacion;
        }
   }
   
   public ArrayList<ubicacion> ConsultarListadoubicacion(String criterio) throws SQLException {
       ArrayList<ubicacion> milistadosubicacion = new ArrayList<ubicacion>();
       ubicacion miubicacion;
       
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn();
       
       try {
           Statement sentencia = nuevaCon.createStatement ();
           String Query = " SELECT idubicacion, departamento, municipio " + "  FROM ubicacion where municipio like '%"+ criterio +"%' ORDER BY idubicacion;";
           ResultSet rs = sentencia.executeQuery(Query);
           while (rs.next()) {
               
               miubicacion = new ubicacion();
               miubicacion.setIdubicacion(rs.getInt(1));
               miubicacion.setDepartamento(rs.getString(2));
               miubicacion.setMunicipio(rs.getString(3));
               milistadosubicacion.add(miubicacion);
           }
           return milistadosubicacion;
       }catch (Exception ex) {
           System.out.println("Error consulta listado de ubicacion:" + ex.getMessage());
           return milistadosubicacion;
       }
       
   }
   
   // Eliminar 
   
   public String Eliminarubicacion(ubicacion ubicacion) {
       String miRespuesta;
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn ();
       
       PreparedStatement sentencia;
       try {
           String Query = " DELETE FROM ubicacion where idubicacion=? and departamento=? and municipio=?;";
           sentencia = nuevaCon.prepareStatement(Query);
           sentencia.setInt(1, ubicacion.getIdubicacion());
           sentencia.setString(2, ubicacion.getDepartamento());
           sentencia.setString(3, ubicacion.getMunicipio());
           
           sentencia.execute();
           miRespuesta = "";
           
       } catch (Exception ex) {
           miRespuesta = ex.getMessage();
           System.err.println("Ocurrio un error en ubicacionDAO.Eliminarubicacion" + ex.getMessage());
       }
       return miRespuesta;
   }
   
}
