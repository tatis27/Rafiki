
package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import modelo.propiedades;

public class propiedadesDAO {
    
    //Adicionar 
    //conexion a la base de datos 
    
    public String propiedades(propiedades propiedades) {
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
    //sentecia     
        PreparedStatement sentencia;
    //try-catch   
        try {
    // consulta         
            String Query = "INSERT INTO propiedades (nombre,direccion,valor_alojamiento,numero_personas,numero_baños,numero_habitaciones,cocina,aire_acondicionado,piscina,numero_estacionamiento,idusuarios,idtipo_alojamiento,idestado_propiedad,idubicacion)"
                    + "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,propiedades.getNombre());
            sentencia.setString(2,propiedades.getDireccion());
            sentencia.setInt(3,propiedades.getValor_alojamiento());
            sentencia.setInt(4,propiedades.getNumero_personas());
            sentencia.setInt(5,propiedades.getNumero_baños());
            sentencia.setInt(6,propiedades.getNumero_habitaciones());
            sentencia.setInt(7,propiedades.getCocina());
            sentencia.setInt(8,propiedades.getAire_acondicionado());
            sentencia.setInt(9,propiedades.getPiscina());
            sentencia.setInt(10,propiedades.getNumero_estacionamiento());
            sentencia.setInt(11,propiedades.getIdusuarios());
            sentencia.setInt(12,propiedades.getIdtipo_alojamiento());
            sentencia.setInt(13,propiedades.getIdestado_propiedad());
            sentencia.setInt(14,propiedades.getIdubicacion());
            
            sentencia.execute();
            miRespuesta = "";
            
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un problea en propiedadesDAO\n " + ex.getMessage());
        }
        
        return miRespuesta;
    }
    
    //Actualizar 
    
    public String actualizarpropiedades (propiedades propiedades){
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try {
            String Query = "update propiedades set nombre=?, direccion=?, valor_alojamiento=?, numero_personas=?, numero_baños=?, numero_habitaciones=?, cocina=?, aire_acondicionado=?, piscina=?, numero_estacionamiento=?, idusuarios=?, idtipo_alojamiento=?, idestado_propiedad=?, idubicacion=? where idpropiedades=?";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setString(1,propiedades.getNombre());
            sentencia.setString(2,propiedades.getDireccion());
            sentencia.setInt(3,propiedades.getValor_alojamiento());
            sentencia.setInt(4,propiedades.getNumero_personas());
            sentencia.setInt(5,propiedades.getNumero_personas());
            sentencia.setInt(6,propiedades.getNumero_habitaciones());
            sentencia.setInt(7,propiedades.getCocina());
            sentencia.setInt(8,propiedades.getAire_acondicionado());
            sentencia.setInt(9,propiedades.getPiscina());
            sentencia.setInt(10,propiedades.getNumero_estacionamiento());
            sentencia.setInt(11,propiedades.getIdusuarios());
            sentencia.setInt(12,propiedades.getIdtipo_alojamiento());
            sentencia.setInt(13,propiedades.getIdestado_propiedad());
            sentencia.setInt(14,propiedades.getIdubicacion());
            sentencia.setInt(15,propiedades.getIdpropiedades());
          
            
            sentencia.executeUpdate();
            miRespuesta = "";
            
        } catch (Exception ex) {
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en propiedadesDAO\n" + ex.getMessage());
        }
        return miRespuesta;
    }
   
    // Consultar
    
    public propiedades consultarpropiedades (int idpropiedades) {
       propiedades mipropiedades = null;
       
       Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        try {
            Statement sentencia = nuevaCon.createStatement();
            String Query = "select idpropiedades, nombre, direccion, valor_alojamiento, numero_personas, numero_baños, numero_habitaciones, cocina, aire_acondicionado, piscina, numero_estacionamiento, idusuarios, idtipo_alojamiento, idestado_propiedad, idubicacion from propiedades where idpropiedades ="+ idpropiedades;
            ResultSet rs = sentencia.executeQuery(Query);
            while (rs.next()) {
                mipropiedades = new propiedades ();
                mipropiedades.setIdpropiedades(rs.getInt(1));
                mipropiedades.setNombre(rs.getString(2));
                mipropiedades.setDireccion(rs.getString(3));
                mipropiedades.setValor_alojamiento(rs.getInt(4));
                mipropiedades.setNumero_personas(rs.getInt(5));
                mipropiedades.setNumero_baños(rs.getInt(6));
                mipropiedades.setNumero_habitaciones(rs.getInt(7));
                mipropiedades.setCocina(rs.getInt(8));
                mipropiedades.setAire_acondicionado(rs.getInt(9));
                mipropiedades.setPiscina(rs.getInt(10));
                mipropiedades.setNumero_estacionamiento(rs.getInt(11));
                mipropiedades.setIdusuarios(rs.getInt(12));
                mipropiedades.setIdtipo_alojamiento(rs.getInt(13));
                mipropiedades.setIdestado_propiedad(rs.getInt(14));
                mipropiedades.setIdubicacion(rs.getInt(15));
                
            }
            return mipropiedades;
        }catch (Exception ex) {
            System.out.println(ex.getMessage());
            return mipropiedades;
        }
   }
    
    public ArrayList<propiedades> ConsultarListadopropiedades(String criterio) throws SQLException {
       ArrayList<propiedades> milistadospropiedades = new ArrayList<propiedades>();
       propiedades mipropiedades;
       
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn();
       
       try {
           Statement sentencia = nuevaCon.createStatement ();
           String Query = " SELECT idpropiedades, nombre, direccion, valor_alojamiento, numero_personas, numero_baños, numero_habitaciones, cocina, aire_acondicionado, piscina, numero_estacionamiento, idusuarios, idtipo_alojamiento, idestado_propiedad, idubicacion " + "  FROM propiedades where idubicacion like '%"+ criterio +"%' ORDER BY idpropiedades;";
           ResultSet rs = sentencia.executeQuery(Query);
           while (rs.next()) {
               
               mipropiedades = new propiedades();
               mipropiedades.setIdpropiedades(rs.getInt(1));
               mipropiedades.setNombre(rs.getString(2));
               mipropiedades.setDireccion(rs.getString(3));
               mipropiedades.setValor_alojamiento(rs.getInt(4));
               mipropiedades.setNumero_personas(rs.getInt(5));
               mipropiedades.setNumero_baños(rs.getInt(6));
               mipropiedades.setNumero_habitaciones(rs.getInt(7));
               mipropiedades.setCocina(rs.getInt(8));
               mipropiedades.setAire_acondicionado(rs.getInt(9));
               mipropiedades.setPiscina(rs.getInt(10));
               mipropiedades.setNumero_estacionamiento(rs.getInt(11));
               mipropiedades.setIdusuarios(rs.getInt(12));
               mipropiedades.setIdtipo_alojamiento(rs.getInt(13));
               mipropiedades.setIdestado_propiedad(rs.getInt(14));
               mipropiedades.setIdubicacion(rs.getInt(15));
               milistadospropiedades.add(mipropiedades);
           }
           return milistadospropiedades;
       }catch (Exception ex) {
           System.out.println("Error consulta listado de Propiedades:" + ex.getMessage());
           return milistadospropiedades;
       }
       
   }
   
   // Eliminar 
   
    public String Eliminarpropiedades(propiedades propiedades) {
       String miRespuesta;
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn ();
       
       PreparedStatement sentencia;
       try {
           String Query = " DELETE FROM propiedades where idpropiedades=? and nombre=? and direccion=? and valor_alojamiento=? and numero_personas=? and numero_baños=? and numero_habitaciones=? and cocina=? and aire_acondicionado=? and piscina=? and numero_estacionamiento=? and idusuarios=? and idtipo_alojamiento=? and idestado_propiedad=? and idubicacion=?";
           sentencia = nuevaCon.prepareStatement(Query);
           sentencia.setInt(1, propiedades.getIdpropiedades());
           sentencia.setString(2, propiedades.getNombre());
           sentencia.setString(3, propiedades.getDireccion());
           sentencia.setInt(4, propiedades.getValor_alojamiento());
           sentencia.setInt(5, propiedades.getNumero_personas());
           sentencia.setInt(6, propiedades.getNumero_baños());
           sentencia.setInt(7, propiedades.getNumero_habitaciones());
           sentencia.setInt(8, propiedades.getCocina());
           sentencia.setInt(9, propiedades.getAire_acondicionado());
           sentencia.setInt(10, propiedades.getPiscina());
           sentencia.setInt(11, propiedades.getNumero_estacionamiento());
           sentencia.setInt(12, propiedades.getIdusuarios());
           sentencia.setInt(13, propiedades.getIdtipo_alojamiento());
           sentencia.setInt(14, propiedades.getIdestado_propiedad());
           sentencia.setInt(15, propiedades.getIdubicacion());
           
           sentencia.execute();
           miRespuesta = "";
           
       } catch (Exception ex) {
           miRespuesta = ex.getMessage();
           System.err.println("Ocurrio un error en propiedadesDAO.Eliminarpropiedades" + ex.getMessage());
       }
       return miRespuesta;
   }
   
}


