
package controlador;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import modelo.pagos;

public class pagosDAO {
    
    //Adicionar 
    //conexion a la base de datos 
    
    public String pagos (pagos pagos) {
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
    //sentecia     
        PreparedStatement sentencia;
    //try-catch   
        try {
    // consulta         
            String Query = "INSERT INTO pagos (valor,fecha_transferencia,numero_transferencia,descripcion,idreservas,idestado_pago) "
                    + " VALUES (?,?,?,?,?,?)";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setInt(1,pagos.getValor());
            sentencia.setString(2,pagos.getFecha_transferencia());
            sentencia.setInt(3,pagos.getNumero_transferencia());
            sentencia.setString(4,pagos.getDescripcion());
            sentencia.setInt(5,pagos.getIdreservas());
            sentencia.setInt(6,pagos.getIdestado_pago());
            
            sentencia.execute();
            miRespuesta = "";
            
        } catch (Exception ex){
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un problea en pagosDAO\n " + ex.getMessage());
        }
        
        return miRespuesta;
    }
    
    //Actualizar 
    
    public String actualizarpagos (pagos pagos){
        String miRespuesta;
        Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        PreparedStatement sentencia;
        try {
            String Query = "update pagos set valor=?, fecha_transferencia=?, numero_transferencia=?, descripcion=?, idreservas=?, idestado_pago=? where idpagos=?";
            sentencia = nuevaCon.prepareStatement(Query);
            sentencia.setInt(1,pagos.getValor());
            sentencia.setString(2,pagos.getFecha_transferencia());
            sentencia.setInt(3,pagos.getNumero_transferencia());
            sentencia.setString(4,pagos.getDescripcion());
            sentencia.setInt(5,pagos.getIdreservas());
            sentencia.setInt(6,pagos.getIdestado_pago());
            sentencia.setInt(7,pagos.getIdpagos());
          
            
            sentencia.executeUpdate();
            miRespuesta = "";
            
        } catch (Exception ex) {
            miRespuesta = ex.getMessage();
            System.err.println("Ocurrio un error en pagosDAO\n" + ex.getMessage());
        }
        return miRespuesta;
    }
   
    // Consultar
    
    public pagos consultarpagos(int idpagos) {
       pagos mipagos = null;
       
       Conexion miConexion = new Conexion();
        Connection nuevaCon;
        nuevaCon = miConexion.getConn();
        
        try {
            Statement sentencia = nuevaCon.createStatement();
            String Query = "select idpagos, valor, fecha_transferencia, numero_transferencia, descripcion, idreservas, idestado_pago from pagos where idpagos ="+ idpagos;
            ResultSet rs = sentencia.executeQuery(Query);
            while (rs.next()) {
                mipagos = new pagos ();
                mipagos.setIdpagos(rs.getInt(1));
                mipagos.setValor(rs.getInt(2));
                mipagos.setFecha_transferencia(rs.getString(3));
                mipagos.setNumero_transferencia(rs.getInt(4));
                mipagos.setDescripcion(rs.getString(5));
                mipagos.setIdreservas(rs.getInt(6));
                mipagos.setIdestado_pago(rs.getInt(7));
                
            }
            return mipagos;
        }catch (Exception ex) {
            System.out.println(ex.getMessage());
            return mipagos;
        }
   }
    
    public ArrayList<pagos> ConsultarListadopagos(String criterio) throws SQLException {
       ArrayList<pagos> milistadospagos = new ArrayList<pagos>();
       pagos mipagos;
       
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn();
       
       try {
           Statement sentencia = nuevaCon.createStatement ();
           String Query = " SELECT idpagos, valor, fecha_transferencia, numero_transferencia, descripcion, idreservas, idestado_pago " + "  FROM pagos where idestado_pago like '%"+ criterio +"%' ORDER BY idpagos;";
           ResultSet rs = sentencia.executeQuery(Query);
           while (rs.next()) {
               
               mipagos = new pagos();
               mipagos.setIdpagos(rs.getInt(1));
               mipagos.setValor(rs.getInt(2));
               mipagos.setFecha_transferencia(rs.getString(3));
               mipagos.setNumero_transferencia(rs.getInt(4));
               mipagos.setDescripcion(rs.getString(5));
               mipagos.setIdreservas(rs.getInt(6));
               mipagos.setIdestado_pago(rs.getInt(7));
               milistadospagos.add(mipagos);
           }
           return milistadospagos;
       }catch (Exception ex) {
           System.out.println("Error consulta listado de Pagos:" + ex.getMessage());
           return milistadospagos;
       }
       
   }
   
   // Eliminar 
   
    public String Eliminarpagos(pagos pagos) {
       String miRespuesta;
       Conexion miConexion = new Conexion();
       Connection nuevaCon;
       nuevaCon = miConexion.getConn ();
       
       PreparedStatement sentencia;
       try {
           String Query = " DELETE FROM pagos where idpagos=? and valor=? and fecha_transferencia=? and numero_transferencia=? and descripcion=? and idreservas=? and idestado_pago=?";
           sentencia = nuevaCon.prepareStatement(Query);
           sentencia.setInt(1, pagos.getIdpagos());
           sentencia.setInt(2, pagos.getValor());
           sentencia.setString(3, pagos.getFecha_transferencia());
           sentencia.setInt(4, pagos.getNumero_transferencia());
           sentencia.setString(5, pagos.getDescripcion());
           sentencia.setInt(6, pagos.getIdreservas());
           sentencia.setInt(7, pagos.getIdestado_pago());
           
           
           sentencia.execute();
           miRespuesta = "";
           
       } catch (Exception ex) {
           miRespuesta = ex.getMessage();
           System.err.println("Ocurrio un error en pagosDAO.Eliminarpagos" + ex.getMessage());
       }
       return miRespuesta;
   }
   
}


