package Prueba;

import controlador.tipo_documentoDAO;
import modelo.tipo_documento;

public class Pruebatipo_documentoConsultar {
    
    public static void main (String[] args) {
        
        tipo_documentoDAO tipo_documentoDAO = new tipo_documentoDAO();
        tipo_documento mitipo_documento = tipo_documentoDAO.consultartipo_documento(2);
        
        if (mitipo_documento != null) {
            System.out.println("Se encontro el tipo de documento" + mitipo_documento.getIdtipo_documento() + " - " 
                    + mitipo_documento.getTipo_documento());
        }else {
            System.out.println("No se encontro el tipo de documento");
        }
    }
    
}
