
package Prueba;

import controlador.actividades_adicionalesDAO;
import modelo.actividades_adicionales;

public class Pruebaactividades_adicionalesConsultar {
    
    public static void main (String[] args) {
        
        actividades_adicionalesDAO actividades_adicionalesDAO = new actividades_adicionalesDAO();
        actividades_adicionales miactividades_adicionales = actividades_adicionalesDAO.consultaractividades_adicionales(2);
        
        if (miactividades_adicionales != null) {
            System.out.println("Se encontro la actividad adicional" + miactividades_adicionales.getIdactividades_adicionales() + " - "
                    + miactividades_adicionales.getNombre() + " - " + miactividades_adicionales.getIdubicacion());
        }else {
            System.out.println("No se encontro la actividad adicional");
        }
    }
}
