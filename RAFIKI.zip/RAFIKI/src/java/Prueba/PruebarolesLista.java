
package Prueba;

import controlador.rolesDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.roles;


public class PruebarolesLista {
    
    public static void main(String[] args) throws SQLException {
        rolesDAO rolesDAO = new rolesDAO();
        ArrayList<roles> miroles = new ArrayList<roles>();
        miroles = rolesDAO.ConsultarListadoroles("");
        
        int size = miroles.size();
        System.out.println("<table border=\"1\"><tr><td><idroles</td><td>nombre>/td>");
        
        for (roles D : miroles) {
            System.out.println("<tr>");
            System.out.println("<td>" + D.getIdroles() + "</td>");
            System.out.println("<td>" + D.getNombre() + "</td>");
            System.out.println("</tr>");
        }
        System.out.println("</table>");
    }
    
}
