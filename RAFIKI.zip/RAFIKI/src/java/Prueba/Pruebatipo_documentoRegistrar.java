
package Prueba;

import controlador.tipo_documentoDAO;
import java.util.Scanner;
import modelo.tipo_documento;


public class Pruebatipo_documentoRegistrar {
    
    public static void main(String[] args) {
        tipo_documentoDAO tipo_documentoDAO = new tipo_documentoDAO();
        tipo_documento mistipo_documento = new tipo_documento();
        
        Scanner Leer = new Scanner (System.in);
        
        String tipo_documento = "";
       
        
        System.out.println("Por favor digite el nombre del tipo de documento");
        tipo_documento = Leer.nextLine();
         
        mistipo_documento.setTipo_documento(tipo_documento);
        mistipo_documento.setIdtipo_documento(1);
        
        String respuesta = tipo_documentoDAO.adicionartipo_documento (mistipo_documento);
        
        if (respuesta.length()== 0) {
            System.out.println("registrado");
        } else {
            System.out.println("Error" + respuesta);
        }
    }
    
}
