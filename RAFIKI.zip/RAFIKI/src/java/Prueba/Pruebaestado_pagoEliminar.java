package Prueba;

import controlador.estado_pagoDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.estado_pago;


public class Pruebaestado_pagoEliminar {
    
    public static void main(String[] args) throws SQLException {
        estado_pagoDAO estado_pagoDAO = new estado_pagoDAO();
        estado_pago miestado_pago = estado_pagoDAO.Consultarestado_pago(50);
        
        if (miestado_pago != null) {
            System.out.println("tipoestado_pago: " + miestado_pago.getTipoestado_pago());
        } else {
            System.out.println("El tipo pago no existe");
        }
        
    //ubicacionDAO ubicacionDAO = new ubicacionDAO();
    ArrayList<estado_pago> listadoestado_pago = estado_pagoDAO.ConsultarListadoestado_pago("");
    
    for (estado_pago T : listadoestado_pago) {
        System.out.println("id." + T.getIdestado_pago() + "TIPO: " + T.getTipoestado_pago());
    }
    System.out.println("**********************************");
    System.out.println("SE VA A ELIMINAR ID: " + listadoestado_pago.get(4).getIdestado_pago());
    System.out.println("SE VA A ELIMINAR: " + listadoestado_pago.get(4).getTipoestado_pago());
    System.out.println("**********************************");
    
    estado_pagoDAO.Eliminarestado_pago(listadoestado_pago.get(4));
    listadoestado_pago = estado_pagoDAO.ConsultarListadoestado_pago("");
    
    for (estado_pago T : listadoestado_pago) {
        System.out.println("id. " + T.getIdestado_pago() + " TIPO: " + T.getTipoestado_pago());
    }
    }
    
   
}

