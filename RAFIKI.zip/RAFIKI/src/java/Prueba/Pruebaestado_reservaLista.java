
package Prueba;

import controlador.estado_reservaDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.estado_reserva;


public class Pruebaestado_reservaLista {
    
    public static void main(String[] args) throws SQLException {
        estado_reservaDAO estado_reservaDAO = new estado_reservaDAO();
        ArrayList<estado_reserva> miestado_reserva = new ArrayList<estado_reserva>();
        miestado_reserva = estado_reservaDAO.ConsultarListadoestado_reserva("");
        
        int size = miestado_reserva.size();
        System.out.println("<table border=\"1\"><tr><td><idestado_reserva</td><td>tipoestado_reserva>/td>");
        
        for (estado_reserva D : miestado_reserva) {
            System.out.println("<tr>");
            System.out.println("<td>" + D.getIdestado_reserva() + "</td>");
            System.out.println("<td>" + D.getTipoestado_reserva() + "</td>");
            System.out.println("</tr>");
        }
        System.out.println("</table>");
    }
    
}
