
package Prueba;

import controlador.ubicacionDAO;
import modelo.ubicacion;

public class PruebaubicacionConsultar {
    
    public static void main (String[] args) {
        
        ubicacionDAO ubicacionDAO = new ubicacionDAO();
        ubicacion miubicacion = ubicacionDAO.consultarubicion(19);
        
        if (miubicacion != null) {
            System.out.println("Encontrado la ubicacion" + miubicacion.getIdubicacion() + " - " 
                    + miubicacion.getDepartamento() + " - " + miubicacion.getMunicipio());
        }else {
            System.out.println("No se encontro la ubicacion");
        }
    }
    
}
