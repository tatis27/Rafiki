
package Prueba;

import controlador.reservasDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.reservas;


public class PruebareservasLista {
    
    public static void main(String[] args) throws SQLException {
        reservasDAO reservasDAO = new reservasDAO();
        ArrayList<reservas> mireservas = new ArrayList<reservas>();
        mireservas = reservasDAO.ConsultarListadoreservas("");
        
        int size = mireservas.size();
        System.out.println("<table border=\"1\"><tr><td><idreservas</td><td>fecha_inicio>/td><td>fecha_final</td><td>fecha_estadoreserva</td><td>idusuarios</td><td>idestado_reserva</td><td>idpropiedades</td>");
        
        for (reservas D : mireservas) {
            System.out.println("<tr>");
            System.out.println("<td>" + D.getIdreservas() + "</td>");
            System.out.println("<td>" + D.getFecha_inicio() + "</td>");
            System.out.println("<td>" + D.getFecha_final() + "</td>");
            System.out.println("<td>" + D.getFecha_estadoreserva() + "</td>");
            System.out.println("<td>" + D.getIdusuarios() + "</td>");
            System.out.println("<td>" + D.getIdestado_reserva() + "</td>");
            System.out.println("<td>" + D.getIdpropiedades() + "</td>");
            System.out.println("</tr>");
        }
        System.out.println("</table>");
    }
    
}