package Prueba;

import controlador.tipo_documentoDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.tipo_documento;


public class Pruebatipo_documentoEliminar {
    
    public static void main(String[] args) throws SQLException {
        tipo_documentoDAO tipo_documentoDAO = new tipo_documentoDAO();
        tipo_documento mitipo_documento = tipo_documentoDAO.consultartipo_documento(20);
        
        if (mitipo_documento != null) {
            System.out.println("tipo_documento: " + mitipo_documento.getTipo_documento());
        } else {
            System.out.println("El tipo de documento no existe");
        }
        
    //ubicacionDAO ubicacionDAO = new ubicacionDAO();
    ArrayList<tipo_documento> listadotipo_documento = tipo_documentoDAO.ConsultarListadotipo_documento("");
    
    for (tipo_documento T : listadotipo_documento) {
        System.out.println("id." + T.getIdtipo_documento() + "TIPO: " + T.getTipo_documento());
    }
    System.out.println("**********************************");
    System.out.println("SE VA A ELIMINAR ID: " + listadotipo_documento.get(4).getIdtipo_documento());
    System.out.println("SE VA A ELIMINAR: " + listadotipo_documento.get(4).getTipo_documento());
    System.out.println("**********************************");
    
    tipo_documentoDAO.Eliminartipo_documento(listadotipo_documento.get(4));
    listadotipo_documento = tipo_documentoDAO.ConsultarListadotipo_documento("");
    
    for (tipo_documento T : listadotipo_documento) {
        System.out.println("id. " + T.getIdtipo_documento() + " TIPO: " + T.getTipo_documento());
    }
    }
    
   
}
