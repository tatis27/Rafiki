
package Prueba;

import controlador.tipo_alojamientoDAO;
import modelo.tipo_alojamiento;

public class Pruebatipo_alojamientoConsultar {
    
    public static void main (String[] args) {
        
        tipo_alojamientoDAO tipo_alojamientoDAO = new tipo_alojamientoDAO();
        tipo_alojamiento mitipo_alojamiento = tipo_alojamientoDAO.consultartipo_alojamiento(2);
        
        if (mitipo_alojamiento != null) {
            System.out.println("Se encontro el tipo de alojamiento" + mitipo_alojamiento.getIdtipo_alojamiento() + " - " 
                    + mitipo_alojamiento.getTipo_alojamiento());
        }else {
            System.out.println("No se encontro el tipo de alojamiento");
        }
    }
    
}
