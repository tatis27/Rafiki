
package Prueba;

import controlador.pagosDAO;
import java.util.Scanner;
import modelo.pagos;

public class PruebapagosActualizar {
    
    public static void main(String[] args) {
    // modificar 
        pagosDAO pagosDAO = new pagosDAO();
        pagos mispagos = new pagos();
        
        Scanner Leer = new Scanner(System.in);
        
        int valor = 0;
        String fecha_transferencia = "";
        int numero_transferencia = 0;
        String descripcion= "";
        
        
        System.out.println("Por favor actualice el valor");
        valor = Leer.nextInt();
        mispagos.setValor(valor);
        
        System.out.println("Por favor actualice la fecha de transferencia");
        fecha_transferencia = Leer.next();
        mispagos.setFecha_transferencia(fecha_transferencia);
        
        System.out.println("Por favor actualice el numero transferencia");
        numero_transferencia = Leer.nextInt();
        mispagos.setNumero_transferencia(numero_transferencia);
        
        System.out.println("Por favor actualice la descripcion");
        descripcion = Leer.next();
        mispagos.setDescripcion(descripcion);
        
        mispagos.setIdreservas(3);
        mispagos.setIdestado_pago(1);
        mispagos.setIdpagos(7);
        
        String respuesta = pagosDAO.actualizarpagos(mispagos);
        
        if (respuesta.length() == 0) {
            System.out.println("Información Actualizada");
        } else {
            System.out.println("Error" + respuesta);
        }
    }
    
}
