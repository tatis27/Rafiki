
package Prueba;

import controlador.estado_reservaDAO;
import modelo.estado_reserva;

public class Pruebaestado_reservaConsultar {
    
    public static void main (String[] args) {
        
        estado_reservaDAO estado_reservaDAO = new estado_reservaDAO();
        estado_reserva miestado_reserva = estado_reservaDAO.Consultarestado_reserva(1);
        
        if (miestado_reserva != null) {
            System.out.println("Se encontro el estado de reserva" + miestado_reserva.getIdestado_reserva() + " - " 
                    + miestado_reserva.getTipoestado_reserva());
        }else {
            System.out.println("No se encontro el estado de reserva");
        }
    }
    
}
