package Prueba;

import controlador.rolesDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.roles;


public class PruebarolesEliminar {
    
    public static void main(String[] args) throws SQLException {
        rolesDAO rolesDAO = new rolesDAO();
        roles miroles = rolesDAO.consultarroles(50);
        
        if (miroles != null) {
            System.out.println("nombre: " + miroles.getNombre());
        } else {
            System.out.println("El rol no existe");
        }
        
    //ubicacionDAO ubicacionDAO = new ubicacionDAO();
    ArrayList<roles> listadoroles = rolesDAO.ConsultarListadoroles("");
    
    for (roles T : listadoroles) {
        System.out.println("id." + T.getIdroles() + "TIPO: " + T.getNombre());
    }
    System.out.println("**********************************");
    System.out.println("SE VA A ELIMINAR ID: " + listadoroles.get(6).getIdroles());
    System.out.println("SE VA A ELIMINAR: " + listadoroles.get(6).getNombre());
    System.out.println("**********************************");
    
    rolesDAO.Eliminarroles(listadoroles.get(6));
    listadoroles = rolesDAO.ConsultarListadoroles("");
    
    for (roles T : listadoroles) {
        System.out.println("id. " + T.getIdroles() + " nombre: " + T.getNombre());
    }
    }
    
   
}
