
package Prueba;

import controlador.tipo_documentoDAO;
import java.util.Scanner;
import modelo.tipo_documento;

public class Pruebatipo_documentoActualizar {
    
    public static void main(String[] args) {
    // modificar 
        tipo_documentoDAO tipo_documentoDAO = new tipo_documentoDAO();
        tipo_documento mistipo_documento = new tipo_documento();
        
        Scanner Leer = new Scanner(System.in);
        
        String tipo_documento = "";
       
        System.out.println("Por favor actualice el tipo documento");
        tipo_documento = Leer.nextLine();
        
        mistipo_documento.setTipo_documento(tipo_documento);
        
         mistipo_documento.setIdtipo_documento(5);
        
        String respuesta = tipo_documentoDAO.actualizartipo_documento(mistipo_documento);
        
        if (respuesta.length() == 0) {
            System.out.println("Información Actualizada");
        } else {
            System.out.println("Error" + respuesta);
        }
    }
    
}
