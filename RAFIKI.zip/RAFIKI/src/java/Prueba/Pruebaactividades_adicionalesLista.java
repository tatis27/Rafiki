package Prueba;

import controlador.actividades_adicionalesDAO;
import static java.lang.System.out;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.actividades_adicionales;


public class Pruebaactividades_adicionalesLista {
    
    public static void main(String[] args) throws SQLException {
        actividades_adicionalesDAO actividades_adicionalesDAO = new actividades_adicionalesDAO();
        ArrayList<actividades_adicionales> miactividades_adicionales = new ArrayList<actividades_adicionales>();
        miactividades_adicionales = actividades_adicionalesDAO.ConsultarListadoactividades_adicionales("");
        
        int size = miactividades_adicionales.size();
        System.out.println("<table border=\"1\"><tr><td><idactividades_adicionales</td><td>nombre>/td><td>idubicacion</td>");
        
        for (actividades_adicionales D : miactividades_adicionales) {
            System.out.println("<tr>");
            System.out.println("<td>" + D.getIdactividades_adicionales() + "</td>");
            System.out.println("<td>" + D.getNombre() + "</td>");
            System.out.println("<td>" + D.getIdubicacion() + "</td>");
            System.out.println("</tr>");
        }
        System.out.println("</table>");
    }
    
}
