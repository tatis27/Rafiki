
package Prueba;

import controlador.usuariosDAO;
import java.util.Scanner;
import modelo.Usuarios;


public class PruebausuariosRegistrar {
    
    public static void main(String[] args) {
        usuariosDAO usuariosDAO = new usuariosDAO();
        Usuarios misusuarios = new Usuarios();
        
        Scanner Leer = new Scanner (System.in);
        
        String nombres ="";
        String apellidos ="";
        String telefono = "";
        String email = "";
        String contrasena = "";
        
   
        System.out.println("Por favor digite el nombre");
        nombres = Leer.nextLine();
        System.out.println("Por favor digite el apellido");
        apellidos = Leer.nextLine();
        System.out.println("Por favor digite el telefono");
        telefono = Leer.nextLine();
        System.out.println("Por favor digite el email");
        email = Leer.nextLine();
        System.out.println("Por favor digite la contraseña");
        contrasena = Leer.nextLine();
        

        misusuarios.setNombres(nombres);
        misusuarios.setApellidos(apellidos);
        misusuarios.setTelefono(telefono);
        misusuarios.setEmail(email);
        misusuarios.setContrasena(contrasena);
        
        misusuarios.setIdroles(1);
        misusuarios.setIdtipo_documento(1);
     
       
        
        String respuesta = usuariosDAO.usuarios (misusuarios);
        
        if (respuesta.length()== 0) {
            System.out.println("registrado");
        } else {
            System.out.println("Error" + respuesta);
        }
    }
    
}