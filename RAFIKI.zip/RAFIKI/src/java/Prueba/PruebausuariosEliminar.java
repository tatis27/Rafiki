package Prueba;

import controlador.usuariosDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.Usuarios;

public class PruebausuariosEliminar {

    public static void main(String[] args) throws SQLException {
        usuariosDAO usuariosDAO = new usuariosDAO();
        Usuarios miusuarios = usuariosDAO.consultarusuarios(50);

        if (miusuarios != null) {
            System.out.println("id: " + miusuarios.getIdtipo_documento());
        } else {
            System.out.println("El usuario no existe");
        }

        //ubicacionDAO ubicacionDAO = new ubicacionDAO();
        ArrayList<Usuarios> listadousuarios = usuariosDAO.ConsultarListadousuarios("");

        for (Usuarios T : listadousuarios) {
            System.out.println("id." + T.getIdusuarios() + "NOMBRES: " + T.getNombres() + "APELLIDOS:" + T.getApellidos() + "TELEFONO" + T.getTelefono() + "EMAIL" + T.getEmail() + "CONTRASENA" + T.getContrasena() + "ID" + T.getIdroles() + "ID" + T.getIdtipo_documento());
    }
    System.out.println("**********************************");
        System.out.println("SE VA A ELIMINAR ID: " + listadousuarios.get(6).getIdusuarios());
        System.out.println("SE VA A ELIMINAR: " + listadousuarios.get(6).getNombres() + "-" + listadousuarios.get(6).getApellidos() + "-" + listadousuarios.get(6).getTelefono() + "-" + listadousuarios.get(6).getEmail() + "-" + listadousuarios.get(6).getContrasena() + "-" + listadousuarios.get(6).getIdroles() + "-" + listadousuarios.get(6).getIdtipo_documento());
        System.out.println("**********************************");

        usuariosDAO.Eliminarusuarios(listadousuarios.get(6));
        listadousuarios = usuariosDAO.ConsultarListadousuarios("");

        for (Usuarios T : listadousuarios) {
            System.out.println("id." + T.getIdusuarios() + "NOMBRES: " + T.getNombres() + "APELLIDOS:" + T.getApellidos() + "TELEFONO" + T.getTelefono() + "EMAIL" + T.getEmail() + "CONTRASENA" + T.getContrasena() + "ID" + T.getIdroles() + "ID" + T.getIdtipo_documento());
        }
    }

}
