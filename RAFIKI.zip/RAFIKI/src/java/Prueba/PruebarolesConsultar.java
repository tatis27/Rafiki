package Prueba;

import controlador.rolesDAO;
import modelo.roles;

public class PruebarolesConsultar {
    
    public static void main (String[] args) {
        
        rolesDAO rolesDAO = new rolesDAO();
        roles miroles = rolesDAO.consultarroles(1);
        
        if (miroles != null) {
            System.out.println("Se encontro el rol" + miroles.getIdroles() + " - " 
                    + miroles.getNombre());
        
        }else {
            System.out.println("No se encontro el rol");
        }
    }
    
}
