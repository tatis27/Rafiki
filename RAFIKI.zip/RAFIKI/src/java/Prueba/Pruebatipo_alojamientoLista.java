
package Prueba;

import controlador.tipo_alojamientoDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.tipo_alojamiento;
import modelo.tipo_alojamiento;


public class Pruebatipo_alojamientoLista {
    
    public static void main(String[] args) throws SQLException {
        tipo_alojamientoDAO tipo_alojamientoDAO = new tipo_alojamientoDAO();
        ArrayList<tipo_alojamiento> mitipo_alojamiento = new ArrayList<tipo_alojamiento>();
        mitipo_alojamiento = tipo_alojamientoDAO.ConsultarListadotipo_alojamiento("");
        
        int size = mitipo_alojamiento.size();
        System.out.println("<table border=\"1\"><tr><td><idtipo_alojamiento</td><td>tipo_alojamiento>/td>");
        
        for (tipo_alojamiento D : mitipo_alojamiento) {
            System.out.println("<tr>");
            System.out.println("<td>" + D.getIdtipo_alojamiento() + "</td>");
            System.out.println("<td>" + D.getTipo_alojamiento() + "</td>");
            System.out.println("</tr>");
        }
        System.out.println("</table>");
    }
    
}