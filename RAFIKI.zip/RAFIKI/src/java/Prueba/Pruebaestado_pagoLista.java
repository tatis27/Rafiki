
package Prueba;

import controlador.estado_pagoDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.estado_pago;


public class Pruebaestado_pagoLista {
    
    public static void main(String[] args) throws SQLException {
        estado_pagoDAO estado_pagoDAO = new estado_pagoDAO();
        ArrayList<estado_pago> miestado_pago = new ArrayList<estado_pago>();
        miestado_pago = estado_pagoDAO.ConsultarListadoestado_pago("");
        
        int size = miestado_pago.size();
        System.out.println("<table border=\"1\"><tr><td><idestado_pago</td><td>tipoestado_pago>/td>");
        
        for (estado_pago D : miestado_pago) {
            System.out.println("<tr>");
            System.out.println("<td>" + D.getIdestado_pago() + "</td>");
            System.out.println("<td>" + D.getTipoestado_pago() + "</td>");
            System.out.println("</tr>");
        }
        System.out.println("</table>");
    }
    
}

