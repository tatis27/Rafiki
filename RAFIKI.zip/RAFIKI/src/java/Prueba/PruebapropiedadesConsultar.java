package Prueba;

import controlador.propiedadesDAO;
import modelo.propiedades;

public class PruebapropiedadesConsultar {
    
    public static void main (String[] args) {
        
        propiedadesDAO propiedadesDAO = new propiedadesDAO();
        propiedades mipropiedades= propiedadesDAO.consultarpropiedades(3);
        
        if (mipropiedades != null) {
            System.out.println("Se encontro la propiedad " + mipropiedades.getIdpropiedades() + " - " 
                    + mipropiedades.getNombre() + " - " + mipropiedades.getDireccion() + " - " 
                    + mipropiedades.getValor_alojamiento() + "-" + mipropiedades.getNumero_personas() + "-"
                    + mipropiedades.getNumero_baños() + "-" + mipropiedades.getNumero_habitaciones() + "-"
                    + mipropiedades.getCocina() + "-" + mipropiedades.getAire_acondicionado() + "-"
                    + mipropiedades.getPiscina() + "-" + mipropiedades.getNumero_estacionamiento() + "-"
                    + mipropiedades.getIdusuarios() + "_" + mipropiedades.getIdtipo_alojamiento() + "-" 
                    + mipropiedades.getIdestado_propiedad() + "-" + mipropiedades.getIdubicacion());
        }else {
            System.out.println("No se encontro la propiedad");
        }
    }
    
}