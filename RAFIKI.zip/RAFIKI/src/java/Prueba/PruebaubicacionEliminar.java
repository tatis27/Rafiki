
package Prueba;

import controlador.ubicacionDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.ubicacion;


public class PruebaubicacionEliminar {
    
    public static void main(String[] args) throws SQLException {
        ubicacionDAO ubicacionDAO = new ubicacionDAO();
        ubicacion miubicacion = ubicacionDAO.consultarubicion(200);
        
        if (miubicacion != null) {
            System.out.println("departamento: " + miubicacion.getDepartamento());
        } else {
            System.out.println("La ubicacion no existe");
        }
        
    //ubicacionDAO ubicacionDAO = new ubicacionDAO();
    ArrayList<ubicacion> listadoubicacion = ubicacionDAO.ConsultarListadoubicacion("");
    
    for (ubicacion T : listadoubicacion) {
        System.out.println("id." + T.getIdubicacion() + "DEPARTAMENTO: " + T.getDepartamento() + "MUNICIPIO:" + T.getMunicipio());
    }
    System.out.println("**********************************");
    System.out.println("SE VA A ELIMINAR ID: " + listadoubicacion.get(120).getIdubicacion());
    System.out.println("SE VA A ELIMINAR: " + listadoubicacion.get(120).getDepartamento() + "-" + listadoubicacion.get(120).getMunicipio());
    System.out.println("**********************************");
    
    ubicacionDAO.Eliminarubicacion(listadoubicacion.get(120));
    listadoubicacion = ubicacionDAO.ConsultarListadoubicacion("");
    
    for (ubicacion T : listadoubicacion) {
        System.out.println("id. " + T.getIdubicacion() + " DEPARTAMENTO: " + T.getDepartamento() + " MUNICIPIO: " + T.getMunicipio());
    }
    }
    
   
}
