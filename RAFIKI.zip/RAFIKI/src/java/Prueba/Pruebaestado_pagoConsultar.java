
package Prueba;

import controlador.estado_pagoDAO;
import modelo.estado_pago;

public class Pruebaestado_pagoConsultar {
    
    public static void main (String[] args) {
        
        estado_pagoDAO estado_pagoDAO = new estado_pagoDAO();
        estado_pago miestado_pago = estado_pagoDAO.Consultarestado_pago(2);
        
        if (miestado_pago != null) {
            System.out.println("Se encontro el estado de pago" + miestado_pago.getIdestado_pago() + " - " 
                    + miestado_pago.getTipoestado_pago());
        }else {
            System.out.println("No se encontro el estado de propiedad");
        }
    }
    
}
