
package Prueba;

import controlador.pagosDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.pagos;


public class PruebapagosLista {
    
    public static void main(String[] args) throws SQLException {
        pagosDAO pagosDAO = new pagosDAO();
        ArrayList<pagos> mipagos = new ArrayList<pagos>();
        mipagos = pagosDAO.ConsultarListadopagos("");
        
        int size = mipagos.size();
        System.out.println("<table border=\"1\"><tr><td><idpagos</td><td>valor>/td><td>fecha_transferencia</td><td>numero_transferencia</td><td>descripcion</td><td>idreservas</td><td>idestado_pago</td>");
        
        for (pagos D : mipagos) {
            System.out.println("<tr>");
            System.out.println("<td>" + D.getIdpagos() + "</td>");
            System.out.println("<td>" + D.getValor() + "</td>");
            System.out.println("<td>" + D.getFecha_transferencia() + "</td>");
            System.out.println("<td>" + D.getNumero_transferencia() + "</td>");
            System.out.println("<td>" + D.getDescripcion() + "</td>");
            System.out.println("<td>" + D.getIdreservas() + "</td>");
            System.out.println("<td>" + D.getIdestado_pago() + "</td>");
            System.out.println("</tr>");
        }
        System.out.println("</table>");
    }
    
}
