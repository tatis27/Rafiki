package Prueba;

import controlador.reservasDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.reservas;


public class PruebareservasEliminar {
    
    public static void main(String[] args) throws SQLException {
        reservasDAO reservasDAO = new reservasDAO();
        reservas mireservas = reservasDAO.consultarreservas(50);
        
        if (mireservas != null) {
            System.out.println("id: " + mireservas.getIdpropiedades());
        } else {
            System.out.println("La reserva no existe");
        }
        
    //ubicacionDAO ubicacionDAO = new ubicacionDAO();
    ArrayList<reservas> listadoreservas= reservasDAO.ConsultarListadoreservas("");
    
    for (reservas T : listadoreservas) {
        System.out.println("id." + T.getIdreservas() + "fecha: " + T.getFecha_inicio() + "Fecha:" + T.getFecha_final() + "Fecha" + T.getFecha_estadoreserva() + "Id" + T.getIdusuarios() + "Id" + T.getIdestado_reserva() + "Ids" + T.getIdpropiedades());
    }
    System.out.println("**********************************");
    System.out.println("SE VA A ELIMINAR ID: " + listadoreservas.get(2).getIdreservas());
    System.out.println("SE VA A ELIMINAR: " + listadoreservas.get(2).getFecha_inicio() + "-" + listadoreservas.get(2).getFecha_final() + "-" + listadoreservas.get(2).getFecha_estadoreserva()  + "-" + listadoreservas.get(2).getIdusuarios() + "-" + listadoreservas.get(2).getIdestado_reserva() + "-" + listadoreservas.get(2).getIdpropiedades());
    System.out.println("**********************************");
    
    reservasDAO.Eliminarreservas(listadoreservas.get(2));
    listadoreservas = reservasDAO.ConsultarListadoreservas("");
    
    for (reservas T : listadoreservas) {
        System.out.println("id." + T.getIdreservas() + "fecha: " + T.getFecha_inicio() + "Fecha:" + T.getFecha_final() + "Fecha" + T.getFecha_estadoreserva() + "Id" + T.getIdusuarios() + "Id" + T.getIdestado_reserva() + "Ids" + T.getIdpropiedades());
    }
    }
    
   
}

