
package Prueba;

import controlador.reservasDAO;
import java.util.Scanner;
import modelo.reservas;

public class PruebareservasActualizar {
    
    public static void main(String[] args) {
    // modificar 
        reservasDAO reservasDAO = new reservasDAO();
        reservas misreservas = new reservas();
        
        Scanner Leer = new Scanner(System.in);
        
        String fecha_inicio ="";
        String fecha_final ="";
        String fecha_estadoreserva = "";
        
        System.out.println("Por favor corregir la fecha inicio");
        fecha_inicio = Leer.nextLine();
        System.out.println("Por favor corregir la fecha final");
        fecha_final = Leer.nextLine();
        System.out.println("Por favor corregir la fecha estado reserva");
        fecha_estadoreserva = Leer.nextLine();

        misreservas.setFecha_inicio(fecha_inicio);
        misreservas.setFecha_final(fecha_final);
        misreservas.setFecha_estadoreserva(fecha_estadoreserva);
        
        misreservas.setIdusuarios(1);
        misreservas.setIdestado_reserva(1);
        misreservas.setIdpropiedades(1);
        misreservas.setIdreservas(15);

        
        String respuesta = reservasDAO.actualizarreservas(misreservas);
        
        if (respuesta.length() == 0) {
            System.out.println("Información Actualizada");
        } else {
            System.out.println("Error" + respuesta);
        }
    }
    
}


