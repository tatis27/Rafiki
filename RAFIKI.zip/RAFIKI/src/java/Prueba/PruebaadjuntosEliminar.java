
package Prueba;

import controlador.adjuntosDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.adjuntos;


public class PruebaadjuntosEliminar {
    
    public static void main(String[] args) throws SQLException {
        adjuntosDAO adjuntosDAO = new adjuntosDAO();
        adjuntos miadjuntos = adjuntosDAO.consultaradjuntos(40);
        
        if (miadjuntos != null) {
            System.out.println("Tipo archivo: " + miadjuntos.getTipo_archivo());
        } else {
            System.out.println("El tipo de archivo no existe");
        }
        
    //ubicacionDAO ubicacionDAO = new ubicacionDAO();
    ArrayList<adjuntos> listadoadjuntos = adjuntosDAO.ConsultarListadoadjuntos("");
    
    for (adjuntos T : listadoadjuntos) {
        System.out.println("id." + T.getIdadjuntos() + "tipo_archivo: " + T.getTipo_archivo() + "ruta_archivo:" + T.getRuta_archivo() + "descripcion:" + T.getDescripcion() + "idpropiedades:" + T.getIdpropiedades());
    }
    System.out.println("**********************************");
    System.out.println("SE VA A ELIMINAR ID: " + listadoadjuntos.get(3).getIdadjuntos());
    System.out.println("SE VA A ELIMINAR: " + listadoadjuntos.get(3).getTipo_archivo() + "-" + listadoadjuntos.get(3).getRuta_archivo() + "-" + listadoadjuntos.get(3).getDescripcion() + "-" + listadoadjuntos.get(3).getIdpropiedades());
    System.out.println("**********************************");
    
    adjuntosDAO.Eliminaradjuntos(listadoadjuntos.get(3));
    listadoadjuntos = adjuntosDAO.ConsultarListadoadjuntos("");
    
    for (adjuntos T : listadoadjuntos) {
        System.out.println("id." + T.getIdadjuntos() + "tipo_archivo: " + T.getTipo_archivo() + "ruta_archivo:" + T.getRuta_archivo() + "descripcion:" + T.getDescripcion() + "idpropiedades:" + T.getIdpropiedades());
    }
    }
    
   
}
