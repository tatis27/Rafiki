
package Prueba;

import controlador.estado_propiedadDAO;
import modelo.estado_propiedad;

public class Pruebaestado_propiedadConsultar {
    
    public static void main (String[] args) {
        
        estado_propiedadDAO estado_propiedadDAO = new estado_propiedadDAO();
        estado_propiedad miestado_propiedad = estado_propiedadDAO.consultarestado_propiedad(2);
        
        if (miestado_propiedad != null) {
            System.out.println("Se encontro el estado de propiedad" + miestado_propiedad.getIdestado_propiedad() + " - " 
                    + miestado_propiedad.getTipoestado_propiedad());
        }else {
            System.out.println("No se encontro el estado de propiedad");
        }
    }
    
}
