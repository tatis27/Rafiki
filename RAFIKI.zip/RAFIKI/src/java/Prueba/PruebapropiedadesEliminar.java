package Prueba;

import controlador.propiedadesDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.propiedades;


public class PruebapropiedadesEliminar {
    
    public static void main(String[] args) throws SQLException {
        propiedadesDAO propiedadesDAO = new propiedadesDAO();
        propiedades mipropiedades = propiedadesDAO.consultarpropiedades(50);
        
        if (mipropiedades != null) {
            System.out.println("id: " + mipropiedades.getIdubicacion());
        } else {
            System.out.println("La Propiedad no existe");
        }
        
    //ubicacionDAO ubicacionDAO = new ubicacionDAO();
    ArrayList<propiedades> listadopropiedades = propiedadesDAO.ConsultarListadopropiedades("");
    
    for (propiedades T : listadopropiedades) {
        System.out.println("id." + T.getIdpropiedades() + "NOMBRE: " + T.getNombre() + "DIRECCION:" + T.getDireccion() + "VALOR ALOJAMIENTO" + T.getValor_alojamiento() + "numero personas" + T.getValor_alojamiento() + "numero baños" + T.getNumero_baños() + "numero_habitaciones" + T.getNumero_habitaciones() + "cocina" + T.getCocina() + "aire_acondicionado" + T.getAire_acondicionado() + "piscina" + T.getPiscina() + "numero_estacionamiento" + T.getNumero_estacionamiento() + "idusuarios" + T.getIdusuarios() + "idtipo_alojamiento" + T.getIdtipo_alojamiento() + "idestado_propiedad" + T.getIdestado_propiedad() + "idubicacion" + T.getIdubicacion());
    }
    System.out.println("**********************************");
    System.out.println("SE VA A ELIMINAR ID: " + listadopropiedades.get(6).getIdpropiedades());
    System.out.println("SE VA A ELIMINAR: " + listadopropiedades.get(6).getNombre() + "-" + listadopropiedades.get(6).getDireccion() + "-" + listadopropiedades.get(6).getValor_alojamiento()  + "-" + listadopropiedades.get(6).getNumero_baños() + "-" + listadopropiedades.get(6).getNumero_habitaciones() + "-" + listadopropiedades.get(6).getCocina() + "-" + listadopropiedades.get(6).getAire_acondicionado() + "-" + listadopropiedades.get(6).getPiscina() + "-" + listadopropiedades.get(6).getNumero_estacionamiento() + "-" + listadopropiedades.get(6).getIdusuarios() + "-" + listadopropiedades.get(6).getIdtipo_alojamiento() + "-" + listadopropiedades.get(6).getIdestado_propiedad() + "-" + listadopropiedades.get(6).getIdubicacion());
    System.out.println("**********************************");
    
    propiedadesDAO.Eliminarpropiedades(listadopropiedades.get(6));
    listadopropiedades = propiedadesDAO.ConsultarListadopropiedades("");
    
    for (propiedades T : listadopropiedades) {
        System.out.println("id." + T.getIdpropiedades() + "NOMBRE: " + T.getNombre() + "DIRECCION:" + T.getDireccion() + "VALOR ALOJAMIENTO" + T.getValor_alojamiento() + "numero personas" + T.getValor_alojamiento() + "numero baños" + T.getNumero_baños() + "numero_habitaciones" + T.getNumero_habitaciones() + "cocina" + T.getCocina() + "aire_acondicionado" + T.getAire_acondicionado() + "piscina" + T.getPiscina() + "numero_estacionamiento" + T.getNumero_estacionamiento() + "idusuarios" + T.getIdusuarios() + "idtipo_alojamiento" + T.getIdtipo_alojamiento() + "idestado_propiedad" + T.getIdestado_propiedad() + "idubicacion" + T.getIdubicacion());
    }
    }
    
   
}

