package Prueba;

import controlador.reservasDAO;
import modelo.reservas;

public class PruebareservasConsultar {
    
    public static void main (String[] args) {
        
        reservasDAO reservasDAO = new reservasDAO();
        reservas mireservas= reservasDAO.consultarreservas(3);
        
        if (mireservas != null) {
            System.out.println("Se encontro la reserva " + mireservas.getIdreservas() + " - " 
                    + mireservas.getFecha_inicio() + " - " + mireservas.getFecha_final() + " - " 
                    + mireservas.getFecha_estadoreserva() + "-" + mireservas.getIdusuarios() + "-"
                    + mireservas.getIdestado_reserva() + "-" + mireservas.getIdpropiedades());
        }else {
            System.out.println("No se encontro la reserva");
        }
    }
    
}