
package Prueba;

import controlador.adjuntosDAO;
import java.util.Scanner;
import modelo.adjuntos;

public class PruebaadjuntosActualizar {
    
    public static void main(String[] args) {
    // modificar 
        adjuntosDAO adjuntosDAO = new adjuntosDAO();
        adjuntos misadjuntos = new adjuntos();
        
        Scanner Leer = new Scanner(System.in);
        
        String tipo_archivo = "";
        String ruta_archivo = "";
        String descripcion = "";
        
        
        System.out.println("Por favor actualice el tipo de archivo");
        tipo_archivo = Leer.nextLine();
        misadjuntos.setTipo_archivo(tipo_archivo);
        
        System.out.println("Por favor actualice la ruta del archivo");
        ruta_archivo = Leer.next();
        misadjuntos.setRuta_archivo(ruta_archivo);
        
        System.out.println("Por favor actualice la descripcion");
        descripcion = Leer.next();
        misadjuntos.setDescripcion(descripcion);
        
        misadjuntos.setIdpropiedades(1);
        misadjuntos.setIdadjuntos(1);
        
        String respuesta = adjuntosDAO.actualizaradjuntos(misadjuntos);
        
        if (respuesta.length() == 0) {
            System.out.println("Información Actualizada");
        } else {
            System.out.println("Error" + respuesta);
        }
    }
    
}
