package Prueba;

import controlador.adjuntosDAO;
import static java.lang.System.out;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.adjuntos;


public class PruebaadjuntosLista {
    
    public static void main(String[] args) throws SQLException {
        adjuntosDAO adjuntosDAO = new adjuntosDAO();
        ArrayList<adjuntos> miadjuntos = new ArrayList<adjuntos>();
        miadjuntos = adjuntosDAO.ConsultarListadoadjuntos("");
        
        int size = miadjuntos.size();
        System.out.println("<table border=\"1\"><tr><td><idadjuntos</td><td>tipo_archivo>/td><td>ruta_archivo>/td><td>descripcion</td><td>idpropiedades</td>");
        
         for (adjuntos D : miadjuntos) {
            System.out.println("<tr>");
            System.out.println("<td>" + D.getIdadjuntos() + "</td>");
            System.out.println("<td>" + D.getTipo_archivo() + "</td>");
            System.out.println("<td>" + D.getRuta_archivo() + "</td>");
            System.out.println("<td>" + D.getDescripcion() + "</td>");
            System.out.println("<td>" + D.getIdpropiedades() + "</td>");
            System.out.println("</tr>");
        }
        System.out.println("</table>");
    }
    
}
