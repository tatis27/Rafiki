package Prueba;

import controlador.usuariosDAO;
import modelo.Usuarios;

public class PruebausuariosConsultar {
    
    public static void main (String[] args) {
        
        usuariosDAO usuariosDAO = new usuariosDAO();
        Usuarios miusuarios= usuariosDAO.consultarusuarios(3);
        
        if (miusuarios != null) {
            System.out.println("Se encontro el usuario " + miusuarios.getIdusuarios() + " - " 
                    + miusuarios.getNombres() + " - " + miusuarios.getApellidos() + " - " 
                    + miusuarios.getTelefono() + "-" + miusuarios.getEmail() + "-"
                    + miusuarios.getContrasena() + "-" + miusuarios.getIdroles() + "-"
                    + miusuarios.getIdtipo_documento());
        }else {
            System.out.println("No se encontro el usuario");
        }
    }
    
}
