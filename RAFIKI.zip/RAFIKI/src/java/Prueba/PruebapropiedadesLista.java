
package Prueba;

import controlador.propiedadesDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.propiedades;


public class PruebapropiedadesLista {
    
    public static void main(String[] args) throws SQLException {
        propiedadesDAO propiedadesDAO = new propiedadesDAO();
        ArrayList<propiedades> mipropiedades = new ArrayList<propiedades>();
        mipropiedades = propiedadesDAO.ConsultarListadopropiedades("");
        
        int size = mipropiedades.size();
        System.out.println("<table border=\"1\"><tr><td><idpropiedades</td><td>nombre>/td><td>direccion</td><td>valor_alojamiento</td><td>numero_personas</td><td>numero_baños</td><td>numero_habitaciones</td><td>cocina</td><td>aire_acondicionado</td><td>piscina</td><td>numero_estacionamiento</td><td>idusuarios</td><td>idtipo_alojamiento</td><td>idestado_propiedad</td><td>idubicacion</td>");
        
        for (propiedades D : mipropiedades) {
            System.out.println("<tr>");
            System.out.println("<td>" + D.getIdpropiedades() + "</td>");
            System.out.println("<td>" + D.getNombre() + "</td>");
            System.out.println("<td>" + D.getDireccion() + "</td>");
            System.out.println("<td>" + D.getValor_alojamiento() + "</td>");
            System.out.println("<td>" + D.getNumero_personas() + "</td>");
            System.out.println("<td>" + D.getNumero_baños() + "</td>");
            System.out.println("<td>" + D.getNumero_habitaciones() + "</td>");
            System.out.println("<td>" + D.getCocina() + "</td>");
            System.out.println("<td>" + D.getAire_acondicionado() + "</td>");
            System.out.println("<td>" + D.getPiscina() + "</td>");
            System.out.println("<td>" + D.getNumero_estacionamiento() + "</td>");
            System.out.println("<td>" + D.getIdusuarios() + "</td>");
            System.out.println("<td>" + D.getIdtipo_alojamiento() + "</td>");
            System.out.println("<td>" + D.getIdestado_propiedad() + "</td>");
            System.out.println("<td>" + D.getIdubicacion() + "</td>");
            
            System.out.println("</tr>");
        }
        System.out.println("</table>");
    }
    
}