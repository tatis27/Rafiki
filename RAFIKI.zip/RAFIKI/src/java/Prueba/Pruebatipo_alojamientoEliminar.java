package Prueba;

import controlador.tipo_alojamientoDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.tipo_alojamiento;


public class Pruebatipo_alojamientoEliminar {
    
    public static void main(String[] args) throws SQLException {
        tipo_alojamientoDAO tipo_alojamientoDAO = new tipo_alojamientoDAO();
        tipo_alojamiento mitipo_alojamiento = tipo_alojamientoDAO.consultartipo_alojamiento(20);
        
        if (mitipo_alojamiento != null) {
            System.out.println("tipo_alojamiento: " + mitipo_alojamiento.getTipo_alojamiento());
        } else {
            System.out.println("El tipo de alojamiento no existe");
        }
        
    //ubicacionDAO ubicacionDAO = new ubicacionDAO();
    ArrayList<tipo_alojamiento> listadotipo_alojamiento = tipo_alojamientoDAO.ConsultarListadotipo_alojamiento("");
    
    for (tipo_alojamiento T : listadotipo_alojamiento) {
        System.out.println("id." + T.getIdtipo_alojamiento() + "TIPO: " + T.getTipo_alojamiento());
    }
    System.out.println("**********************************");
    System.out.println("SE VA A ELIMINAR ID: " + listadotipo_alojamiento.get(7).getIdtipo_alojamiento());
    System.out.println("SE VA A ELIMINAR: " + listadotipo_alojamiento.get(7).getTipo_alojamiento());
    System.out.println("**********************************");
    
    tipo_alojamientoDAO.Eliminartipo_alojamiento(listadotipo_alojamiento.get(7));
    listadotipo_alojamiento = tipo_alojamientoDAO.ConsultarListadotipo_alojamiento("");
    
    for (tipo_alojamiento T : listadotipo_alojamiento) {
        System.out.println("id. " + T.getIdtipo_alojamiento() + " TIPO: " + T.getTipo_alojamiento());
    }
    }
    
   
}
