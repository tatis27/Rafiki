package Prueba;

import controlador.tipo_documentoDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.tipo_documento;


public class Pruebatipo_documentoLista {
    
    public static void main(String[] args) throws SQLException {
        tipo_documentoDAO tipo_documentoDAO = new tipo_documentoDAO();
        ArrayList<tipo_documento> mitipo_documento = new ArrayList<tipo_documento>();
        mitipo_documento = tipo_documentoDAO.ConsultarListadotipo_documento("");
        
        int size = mitipo_documento.size();
        System.out.println("<table border=\"1\"><tr><td><idtipo_documento</td><td>tipo_documento>/td>");
        
        for (tipo_documento D : mitipo_documento) {
            System.out.println("<tr>");
            System.out.println("<td>" + D.getIdtipo_documento() + "</td>");
            System.out.println("<td>" + D.getTipo_documento() + "</td>");
            System.out.println("</tr>");
        }
        System.out.println("</table>");
    }
    
}