package Prueba;

import controlador.pagosDAO;
import modelo.pagos;

public class PruebapagosConsultar {
    
    public static void main (String[] args) {
        
        pagosDAO pagosDAO = new pagosDAO();
        pagos mipagos= pagosDAO.consultarpagos(1);
        
        if (mipagos != null) {
            System.out.println("Se encontro el pago " + mipagos.getIdpagos() + " - " 
                    + mipagos.getValor() + " - " + mipagos.getFecha_transferencia() + " - " 
                    + mipagos.getNumero_transferencia() + "-" + mipagos.getDescripcion() + "-"
                    + mipagos.getIdreservas() + "-"
                    + mipagos.getIdestado_pago());
        }else {
            System.out.println("No se encontro el pago");
        }
    }
    
}
