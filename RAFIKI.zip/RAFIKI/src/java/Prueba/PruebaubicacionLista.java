
package Prueba;

import controlador.ubicacionDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.ubicacion;


public class PruebaubicacionLista {
    
    public static void main(String[] args) throws SQLException {
        ubicacionDAO ubicacionDAO = new ubicacionDAO();
        ArrayList<ubicacion> miubicacion = new ArrayList<ubicacion>();
        miubicacion = ubicacionDAO.ConsultarListadoubicacion("");
        
        int size = miubicacion.size();
        System.out.println("<table border=\"1\"><tr><td><idubicacion</td><td>departamento>/td><td>municipio</td>");
        
        for (ubicacion D : miubicacion) {
            System.out.println("<tr>");
            System.out.println("<td>" + D.getIdubicacion() + "</td>");
            System.out.println("<td>" + D.getDepartamento() + "</td>");
            System.out.println("<td>" + D.getMunicipio() + "</td>");
            System.out.println("</tr>");
        }
        System.out.println("</table>");
    }
    
}
