package Prueba;

import controlador.estado_reservaDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.estado_reserva;


public class Pruebaestado_reservaEliminar {
    
    public static void main(String[] args) throws SQLException {
        estado_reservaDAO estado_reservaDAO = new estado_reservaDAO();
        estado_reserva miestado_reserva = estado_reservaDAO.Consultarestado_reserva(50);
        
        if (miestado_reserva != null) {
            System.out.println("tipoestado_reserva: " + miestado_reserva.getTipoestado_reserva());
        } else {
            System.out.println("El tipo de reserva no existe");
        }
        
    //ubicacionDAO ubicacionDAO = new ubicacionDAO();
    ArrayList<estado_reserva> listadoestado_reserva = estado_reservaDAO.ConsultarListadoestado_reserva("");
    
    for (estado_reserva T : listadoestado_reserva) {
        System.out.println("id." + T.getIdestado_reserva() + "TIPO: " + T.getTipoestado_reserva());
    }
    System.out.println("**********************************");
    System.out.println("SE VA A ELIMINAR ID: " + listadoestado_reserva.get(4).getIdestado_reserva());
    System.out.println("SE VA A ELIMINAR: " + listadoestado_reserva.get(4).getTipoestado_reserva());
    System.out.println("**********************************");
    
    estado_reservaDAO.Eliminarestado_reserva(listadoestado_reserva.get(4));
    listadoestado_reserva = estado_reservaDAO.ConsultarListadoestado_reserva("");
    
    for (estado_reserva T : listadoestado_reserva) {
        System.out.println("id. " + T.getIdestado_reserva() + " TIPO: " + T.getTipoestado_reserva());
    }
    }
    
   
}

