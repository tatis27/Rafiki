
package Prueba;

import controlador.adjuntosDAO;
import modelo.adjuntos;

public class PruebaadjuntosConsultar {
    
    public static void main (String[] args) {
        
       adjuntosDAO adjuntosDAO = new adjuntosDAO();
        adjuntos miadjuntos = adjuntosDAO.consultaradjuntos(2);
        
      if (miadjuntos != null) {
            System.out.println("Se encontro el adjunto" + miadjuntos.getIdadjuntos() + " - "
                    + miadjuntos.getTipo_archivo() + " - " +  miadjuntos.getRuta_archivo() + " - "
                    + miadjuntos.getDescripcion() + " - " + miadjuntos.getIdpropiedades());
        }else {
            System.out.println("No se encontro la actividad adicional");
        }
    }
}

