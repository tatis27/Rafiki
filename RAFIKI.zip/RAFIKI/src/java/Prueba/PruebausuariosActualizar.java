
package Prueba;

import controlador.usuariosDAO;
import java.util.Scanner;
import modelo.Usuarios;

public class PruebausuariosActualizar {
    
    public static void main(String[] args) {
    // modificar 
        usuariosDAO usuariosDAO = new usuariosDAO();
        Usuarios misUsuarios = new Usuarios();
        
        Scanner Leer = new Scanner(System.in);
        
        String nombres = "";
        String apellidos = "";
        String telefono = "";
        String email = "";
        String contrasena = "";

        System.out.println("Por favor corregir el nombre");
        nombres = Leer.nextLine();
        System.out.println("Por favor corregir el apellido");
        apellidos = Leer.nextLine();
        System.out.println("Por favor corregir el telefono");
        telefono = Leer.nextLine();
        System.out.println("Por favor corregir el email");
        email = Leer.nextLine();
        System.out.println("Por favor corregir la contrasena");
        contrasena = Leer.nextLine();
        
        misUsuarios.setNombres(nombres);
        misUsuarios.setApellidos(apellidos);
        misUsuarios.setTelefono(telefono);
        misUsuarios.setEmail(email);
        misUsuarios.setContrasena(contrasena);
        
        misUsuarios.setIdroles(1);
        misUsuarios.setIdtipo_documento(1);
        

        
        String respuesta = usuariosDAO.actualizarusuarios(misUsuarios);
        
        if (respuesta.length() == 0) {
            System.out.println("Información Actualizada");
        } else {
            System.out.println("Error" + respuesta);
        }
    }
    
}


