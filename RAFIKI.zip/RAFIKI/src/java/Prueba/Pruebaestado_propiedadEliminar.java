package Prueba;

import controlador.estado_propiedadDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.estado_propiedad;


public class Pruebaestado_propiedadEliminar {
    
    public static void main(String[] args) throws SQLException {
        estado_propiedadDAO estado_propiedadDAO = new estado_propiedadDAO();
        estado_propiedad miestado_propiedad = estado_propiedadDAO.consultarestado_propiedad(50);
        
        if (miestado_propiedad != null) {
            System.out.println("tipoestado_propiedad: " + miestado_propiedad.getTipoestado_propiedad());
        } else {
            System.out.println("La ubicacion no existe");
        }
        
    //ubicacionDAO ubicacionDAO = new ubicacionDAO();
    ArrayList<estado_propiedad> listadoestado_propiedad = estado_propiedadDAO.ConsultarListadoestado_propiedad("");
    
    for (estado_propiedad T : listadoestado_propiedad) {
        System.out.println("id." + T.getIdestado_propiedad() + "TIPO: " + T.getTipoestado_propiedad());
    }
    System.out.println("**********************************");
    System.out.println("SE VA A ELIMINAR ID: " + listadoestado_propiedad.get(2).getIdestado_propiedad());
    System.out.println("SE VA A ELIMINAR: " + listadoestado_propiedad.get(2).getTipoestado_propiedad());
    System.out.println("**********************************");
    
    estado_propiedadDAO.Eliminarestado_propiedad(listadoestado_propiedad.get(2));
    listadoestado_propiedad = estado_propiedadDAO.ConsultarListadoestado_propiedad("");
    
    for (estado_propiedad T : listadoestado_propiedad) {
        System.out.println("id. " + T.getIdestado_propiedad() + " TIPO: " + T.getTipoestado_propiedad());
    }
    }
    
   
}
