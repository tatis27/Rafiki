
package Prueba;

import controlador.estado_reservaDAO;
import java.util.Scanner;
import modelo.estado_reserva;

public class Pruebaestado_reservaActualizar {
    
    public static void main(String[] args) {
    // modificar 
        estado_reservaDAO estado_reservaDAO = new estado_reservaDAO();
        estado_reserva misestado_reserva = new estado_reserva();
        
        Scanner Leer = new Scanner(System.in);
        
        String tipoestado_reserva ="";
        
        System.out.println("Por favor corriga el tipo de estado de reserva");
        tipoestado_reserva = Leer.nextLine();
        misestado_reserva.setTipoestado_reserva(tipoestado_reserva);
        
        misestado_reserva.setIdestado_reserva(5);
        
        String respuesta = estado_reservaDAO.adicionarestado_reserva(misestado_reserva);
        
        if (respuesta.length() == 0) {
            System.out.println("Información Actualizada");
        } else {
            System.out.println("Error" + respuesta);
        }
    }
    
}