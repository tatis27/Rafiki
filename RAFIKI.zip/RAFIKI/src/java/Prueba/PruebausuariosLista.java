package Prueba;

import controlador.usuariosDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.Usuarios;


public class PruebausuariosLista {
    
    public static void main(String[] args) throws SQLException {
        usuariosDAO usuariosDAO = new usuariosDAO();
        ArrayList<Usuarios> miusuarios = new ArrayList<Usuarios>();
        miusuarios = usuariosDAO.ConsultarListadousuarios("");
        
        int size = miusuarios.size();
        System.out.println("<table border=\"1\"><tr><td><idusuarios</td><td>nombres>/td><td>apellidos</td><td>telefono</td><td>email</td><td>contrasena</td><td>idroles</td><td>idtipo_documento</td>");
        
        for (Usuarios D : miusuarios) {
            System.out.println("<tr>");
            System.out.println("<td>" + D.getIdusuarios() + "</td>");
            System.out.println("<td>" + D.getNombres() + "</td>");
            System.out.println("<td>" + D.getApellidos() + "</td>");
            System.out.println("<td>" + D.getTelefono() + "</td>");
            System.out.println("<td>" + D.getEmail() + "</td>");
            System.out.println("<td>" + D.getContrasena() + "</td>");
            System.out.println("<td>" + D.getIdroles() + "</td>");
            System.out.println("<td>" + D.getIdtipo_documento() + "</td>");
            
            System.out.println("</tr>");
        }
        System.out.println("</table>");
    }
    
}
