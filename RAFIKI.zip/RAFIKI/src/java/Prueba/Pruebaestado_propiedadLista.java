
package Prueba;

import controlador.estado_propiedadDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.estado_propiedad;


public class Pruebaestado_propiedadLista {
    
    public static void main(String[] args) throws SQLException {
        estado_propiedadDAO estado_propiedadDAO = new estado_propiedadDAO();
        ArrayList<estado_propiedad> miestado_propiedad = new ArrayList<estado_propiedad>();
        miestado_propiedad = estado_propiedadDAO.ConsultarListadoestado_propiedad("");
        
        int size = miestado_propiedad.size();
        System.out.println("<table border=\"1\"><tr><td><idestado_propiedad</td><td>tipoestado_propiedad>/td>");
        
        for (estado_propiedad D : miestado_propiedad) {
            System.out.println("<tr>");
            System.out.println("<td>" + D.getIdestado_propiedad() + "</td>");
            System.out.println("<td>" + D.getTipoestado_propiedad() + "</td>");
            System.out.println("</tr>");
        }
        System.out.println("</table>");
    }
    
}
