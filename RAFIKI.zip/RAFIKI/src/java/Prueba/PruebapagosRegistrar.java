package Prueba;

import controlador.pagosDAO;
import java.util.Scanner;
import modelo.pagos;

public class PruebapagosRegistrar {

    public static void main(String[] args) {
        pagosDAO pagosDAO = new pagosDAO();
        pagos mispagos = new pagos();

        Scanner Leer = new Scanner(System.in);

        int valor = 0;
        String fecha_transferencia = "";
        int numero_transferencia = 0;
        String descripcion = "";

        System.out.println("Por favor digite el valor");
        valor = Leer.nextInt();
        System.out.println("Por favor digite la fecha de transferencia");
        fecha_transferencia = Leer.next();
        System.out.println("Por favor digite el numero de transferencia");
        numero_transferencia = Leer.nextInt();
        System.out.println("Por favor digite la descripcion del pago");
        descripcion = Leer.next();

        mispagos.setValor(valor);
        mispagos.setFecha_transferencia(fecha_transferencia);
        mispagos.setNumero_transferencia(numero_transferencia);
        mispagos.setDescripcion(descripcion);

        mispagos.setIdreservas(3);
        mispagos.setIdestado_pago(1);
        mispagos.setIdpagos(7);

        String respuesta = pagosDAO.pagos(mispagos);

        if (respuesta.length() == 0) {
            System.out.println("registrado");
        } else {
            System.out.println("Error" + respuesta);
        }
    }

}
