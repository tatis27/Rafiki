
package Prueba;

import controlador.estado_reservaDAO;
import java.util.Scanner;
import modelo.estado_reserva;


public class Pruebaestado_reservaRegistrar {
    
    public static void main(String[] args) {
        estado_reservaDAO estado_reservaDAO = new estado_reservaDAO();
        estado_reserva misestado_reserva = new estado_reserva();
        
        Scanner Leer = new Scanner (System.in);
        
        String tipoestado_reserva = "";
        
        System.out.println("Por favor digite el estado de la reserva");
        tipoestado_reserva = Leer.next();
        
        misestado_reserva.setTipoestado_reserva(tipoestado_reserva);
        
        String respuesta = estado_reservaDAO.adicionarestado_reserva(misestado_reserva);
        
        if (respuesta.length()== 0) {
            System.out.println("registrado");
        } else {
            System.out.println("Error" + respuesta);
        }
    }
    
}
