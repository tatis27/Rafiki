package Prueba;

import controlador.adjuntosDAO;
import java.util.Scanner;
import modelo.adjuntos;


public class PruebaadjuntosRegistrar {
    
    public static void main(String[] args) {
        adjuntosDAO adjuntosDAO = new adjuntosDAO();
        adjuntos misadjuntos = new adjuntos();
        
        Scanner Leer = new Scanner (System.in);
        
        String tipo_archivo = "";
        String ruta_archivo = "";
        String descripcion = "";
        
       
        
        System.out.println("Por favor digite el nombre del tipo del archivo");
        tipo_archivo = Leer.next();
        System.out.println("Por favor digite el nombre de la ruta del archivo");
        ruta_archivo = Leer.next();
        System.out.println("Por favor digite la descripcion del archivo");
        descripcion = Leer.next();
         
        misadjuntos.setTipo_archivo(tipo_archivo);
        misadjuntos.setRuta_archivo(ruta_archivo);
        misadjuntos.setDescripcion(descripcion);
        
        misadjuntos.setIdpropiedades(3);
        
        String respuesta = adjuntosDAO.adicionaradjuntos (misadjuntos);
        
        if (respuesta.length()== 0) {
            System.out.println("registrado");
        } else {
            System.out.println("Error" + respuesta);
        }
    }
    
}
