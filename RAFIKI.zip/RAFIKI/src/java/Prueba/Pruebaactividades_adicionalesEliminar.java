package Prueba;

import controlador.actividades_adicionalesDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.actividades_adicionales;


public class Pruebaactividades_adicionalesEliminar {
    
    public static void main(String[] args) throws SQLException {
        actividades_adicionalesDAO actividades_adicionalesDAO = new actividades_adicionalesDAO();
        actividades_adicionales miactividades_adicionales = actividades_adicionalesDAO.consultaractividades_adicionales(15);
        
        if (miactividades_adicionales != null) {
            System.out.println("nombre: " + miactividades_adicionales.getNombre());
        } else {
            System.out.println("La actividad adicional no existe");
        }
        
    //ubicacionDAO ubicacionDAO = new ubicacionDAO();
    ArrayList<actividades_adicionales> listadoactividades_adicionales= actividades_adicionalesDAO.ConsultarListadoactividades_adicionales("");
    
    for (actividades_adicionales T : listadoactividades_adicionales) {
        System.out.println("id." + T.getIdactividades_adicionales() + "NOMBRE: " + T.getNombre() + "ID:" + T.getIdubicacion());
    }
    System.out.println("**********************************");
    System.out.println("SE VA A ELIMINAR ID: " + listadoactividades_adicionales.get(7).getIdactividades_adicionales());
    System.out.println("SE VA A ELIMINAR: " + listadoactividades_adicionales.get(7).getNombre() + "-" + listadoactividades_adicionales.get(7).getIdubicacion());
    System.out.println("**********************************");
    
    actividades_adicionalesDAO.Eliminaractividades_adicionales(listadoactividades_adicionales.get(7));
    listadoactividades_adicionales = actividades_adicionalesDAO.ConsultarListadoactividades_adicionales("");
    
    for (actividades_adicionales T : listadoactividades_adicionales) {
        System.out.println("id. " + T.getIdactividades_adicionales() + " NOMBRE: " + T.getNombre() + " ID: " + T.getIdubicacion());
    }
    }
    
   
}
