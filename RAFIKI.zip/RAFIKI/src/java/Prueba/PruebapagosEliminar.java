
package Prueba;

import controlador.pagosDAO;
import java.sql.SQLException;
import java.util.ArrayList;
import modelo.pagos;


public class PruebapagosEliminar {
    
    public static void main(String[] args) throws SQLException {
        pagosDAO pagosDAO = new pagosDAO();
        pagos mipagos = pagosDAO.consultarpagos(200);
        
        if (mipagos != null) {
            System.out.println("Estado pago: " + mipagos.getIdestado_pago());
        } else {
            System.out.println("El pago no existe");
        }
        
    //ubicacionDAO ubicacionDAO = new ubicacionDAO();
    ArrayList<pagos> listadopagos = pagosDAO.ConsultarListadopagos("");
    
    for (pagos T : listadopagos) {
        System.out.println("id." + T.getIdpagos() + "Valor: " + T.getValor() + "Fecha:" + T.getFecha_transferencia() + "Numero:" + T.getNumero_transferencia() + "Descripcion:" + T.getDescripcion() + "Id:" + T.getIdreservas() + "Id:" + T.getIdestado_pago());
    }
    System.out.println("**********************************");
    System.out.println("SE VA A ELIMINAR ID: " + listadopagos.get(3).getIdpagos());
    System.out.println("SE VA A ELIMINAR: " + listadopagos.get(3).getValor() + "-" + listadopagos.get(3).getFecha_transferencia() + "-" + listadopagos.get(3).getNumero_transferencia() + "-" + listadopagos.get(3).getDescripcion() + "-" + listadopagos.get(3).getIdreservas() + "-" + listadopagos.get(3).getIdestado_pago());
    System.out.println("**********************************");
    
    pagosDAO.Eliminarpagos(listadopagos.get(3));
    listadopagos = pagosDAO.ConsultarListadopagos("");
    
    for (pagos T : listadopagos) {
        System.out.println("id." + T.getIdpagos() + "Valor: " + T.getValor() + "Fecha:" + T.getFecha_transferencia() + "Numero:" + T.getNumero_transferencia() + "Descripcion:" + T.getDescripcion() + "Id:" + T.getIdreservas() + "Id:" + T.getIdestado_pago());
    }
    }
    
   
}
