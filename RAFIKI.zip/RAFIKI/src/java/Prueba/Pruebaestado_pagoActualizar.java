
package Prueba;

import controlador.estado_pagoDAO;
import java.util.Scanner;
import modelo.estado_pago;

public class Pruebaestado_pagoActualizar {
    
    public static void main(String[] args) {
    // modificar 
        estado_pagoDAO estado_pagoDAO = new estado_pagoDAO();
        estado_pago misestado_pago = new estado_pago();
        
        Scanner Leer = new Scanner(System.in);
        
        String tipoestado_pago ="";
        
        System.out.println("Por favor corriga el tipo de estado de pago");
        tipoestado_pago = Leer.nextLine();
        misestado_pago.setTipoestado_pago(tipoestado_pago);
        
        misestado_pago.setIdestado_pago(5);
        
        String respuesta = estado_pagoDAO.adicionarestado_pago(misestado_pago);
        
        if (respuesta.length() == 0) {
            System.out.println("Información Actualizada");
        } else {
            System.out.println("Error" + respuesta);
        }
    }
    
}