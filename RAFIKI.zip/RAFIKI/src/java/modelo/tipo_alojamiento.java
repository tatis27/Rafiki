
package modelo;


public class tipo_alojamiento {
    
    private int idtipo_alojamiento;
    private String tipo_alojamiento;
    
    public int getIdtipo_alojamiento() {
        return idtipo_alojamiento;
    }
    
    public void setIdtipo_alojamiento(int idtipo_alojamiento) {
        this.idtipo_alojamiento = idtipo_alojamiento;
    }
    
    public String getTipo_alojamiento() {
        return tipo_alojamiento;
    }
    
    public void setTipo_alojamiento(String tipo_alojamiento) {
        this.tipo_alojamiento = tipo_alojamiento;
    } 
}
