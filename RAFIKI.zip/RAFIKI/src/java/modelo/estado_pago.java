/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author tatianagomez
 */
public class estado_pago {
    
    private int idestado_pago;
    private String tipoestado_pago;

    public int getIdestado_pago() {
        return idestado_pago;
    }

    public void setIdestado_pago(int idestado_pago) {
        this.idestado_pago = idestado_pago;
    }

    public String getTipoestado_pago() {
        return tipoestado_pago;
    }

    public void setTipoestado_pago(String tipoestado_pago) {
        this.tipoestado_pago = tipoestado_pago;
    }
    
}
