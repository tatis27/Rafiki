/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;


public class estado_reserva {
    
    private int idestado_reserva;
    private String tipoestado_reserva;

    public int getIdestado_reserva() {
        return idestado_reserva;
    }

    public void setIdestado_reserva(int idestado_reserva) {
        this.idestado_reserva = idestado_reserva;
    }

    public String getTipoestado_reserva() {
        return tipoestado_reserva;
    }

    public void setTipoestado_reserva(String tipoestado_reserva) {
        this.tipoestado_reserva = tipoestado_reserva;
    }
    
}
