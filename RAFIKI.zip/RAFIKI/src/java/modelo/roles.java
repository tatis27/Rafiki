
package modelo;

public class roles {
    
    private int idroles;
    private String nombre;

    public int getIdroles() {
        return idroles;
    }
    
    public void setIdroles(int idroles){
        this.idroles=idroles;
    }
    
    public String getNombre () {
        return nombre;
    }  
    public void setNombre (String nombre){
        this.nombre=nombre;
    }
}

