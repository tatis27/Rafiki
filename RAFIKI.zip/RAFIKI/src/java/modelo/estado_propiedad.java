
package modelo;

public class estado_propiedad {
    
    private int idestado_propiedad;
    private String tipoestado_propiedad;

    public int getIdestado_propiedad() {
        return idestado_propiedad;
    }

    public void setIdestado_propiedad(int idestado_propiedad) {
        this.idestado_propiedad = idestado_propiedad;
    }

    public String getTipoestado_propiedad() {
        return tipoestado_propiedad;
    }

    public void setTipoestado_propiedad(String estado_propiedad) {
        this.tipoestado_propiedad = estado_propiedad;
    }
    
}
