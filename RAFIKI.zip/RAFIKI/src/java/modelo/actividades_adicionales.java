/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author tatianagomez
 */
public class actividades_adicionales {
    
    private int idactividades_adicionales;
    private String nombre;
    private int idubicacion;

    public int getIdactividades_adicionales() {
        return idactividades_adicionales;
    }

    public void setIdactividades_adicionales(int idactividades_adicionales) {
        this.idactividades_adicionales = idactividades_adicionales;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getIdubicacion() {
        return idubicacion;
    }

    public void setIdubicacion(int idubicacion) {
        this.idubicacion = idubicacion;
    }
}
