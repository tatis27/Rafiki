
package modelo;


public class tipo_documento {
    
    private int idtipo_documento;
    private String tipo_documento;

    public int getIdtipo_documento() {
        return idtipo_documento;
    }

    public void setIdtipo_documento(int idtipo_documento) {
        this.idtipo_documento = idtipo_documento;
    }

    public String getTipo_documento() {
        return tipo_documento;
    }

    public void setTipo_documento(String tipo_documento) {
        this.tipo_documento = tipo_documento;
    }   
}
