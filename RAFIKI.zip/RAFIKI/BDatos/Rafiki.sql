-- crear base de datos 
CREATE DATABASE IF NOT EXISTS rafiki;
-- usar base de datos 
USE rafiki;
-- CREAR LA TABLA ROLES 
CREATE TABLE roles(
    idroles INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(45)
);
-- CREAR LA TABLA tipo_documento
CREATE TABLE tipo_documento (
    idtipo_documento INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    tipo_documento VARCHAR (45)
);
-- CREAR LA TABLA USUARIO
CREATE TABLE usuarios (
        idusuarios INT AUTO_INCREMENT NOT NULL, -- crear sequence para usuario 
        nombres VARCHAR(100) NOT NULL,
        apellidos VARCHAR(100) NOT NULL, 
        telefono VARCHAR(10) NOT NULL, 
        email VARCHAR(50) NOT NULL, 
        contrasena VARCHAR(100) NOT NULL,
        idroles INT NOT NULL,-- almacena el ID del Rol
        idtipo_documento INT NOT NULL,
         
        PRIMARY KEY (idusuarios),
        FOREIGN KEY (idroles) REFERENCES roles(idroles),
        FOREIGN KEY (idtipo_documento) REFERENCES tipo_documento (idtipo_documento)
    );
-- CREAR LA TABLA tipo_alojamiento
CREATE TABLE tipo_alojamiento (
    idtipo_alojamiento INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    tipo_alojamiento VARCHAR(45) NOT NULL
    );
-- CREAR LA TABLA estado_propiedad
CREATE TABLE estado_propiedad (
    idestado_propiedad INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    tipoestado_propiedad VARCHAR(45) NOT NULL
    );
-- CREAR LA TABLA ubicacion
CREATE TABLE ubicacion (
    idubicacion INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
    Departamento VARCHAR(50) NOT NULL,
    municipio VARCHAR(50) NOT NULL
    );
-- CREAR LA TABLA actividades_adicionales 
CREATE TABLE actividades_adicionales (
    idactividades_adicionales INT AUTO_INCREMENT NOT NULL,
    nombre VARCHAR(50) NOT NULL,
    idubicacion INT NOT NULL,

    PRIMARY KEY (idactividades_adicionales),
    FOREIGN KEY (idubicacion) REFERENCES ubicacion (idubicacion)
    );
    -- CREAR LA TABLA propiedades
CREATE TABLE propiedades (
    idpropiedades INT AUTO_INCREMENT NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    direccion VARCHAR(100) NOT NULL,
    valor_alojamiento INT NOT NULL,
    numero_personas INT NOT NULL,
    numero_baños INT NOT NULL,
    numero_habitaciones INT NOT NULL,
    cocina TINYINT  NOT NULL,
    aire_acondicionado TINYINT NOT NULL,
    piscina TINYINT NOT NULL,
    numero_estacionamiento INT NOT NULL,
    idusuarios INT NOT NULL,
    idtipo_alojamiento INT NOT NULL,
    idestado_propiedad INT NOT NULL,
    idubicacion INT NOT NULL,

    PRIMARY KEY (idpropiedades),
    FOREIGN KEY (idusuarios) REFERENCES usuarios (idusuarios),
    FOREIGN KEY (idtipo_alojamiento) REFERENCES tipo_alojamiento (idtipo_alojamiento),
    FOREIGN KEY (idestado_propiedad) REFERENCES estado_propiedad (idestado_propiedad),
    FOREIGN KEY (idubicacion) REFERENCES ubicacion (idubicacion)
    );
    -- CREA LA TABLA adjuntos
CREATE TABLE adjuntos (
    idadjuntos INT AUTO_INCREMENT NOT NULL,
    tipo_archivo VARCHAR(45) NOT NULL,
    ruta_archivo VARCHAR(45) NOT NULL,
    descripcion VARCHAR(100) NOT NULL,
    idpropiedades INT NOT NULL,

    PRIMARY KEY (idadjuntos),
    FOREIGN KEY (idpropiedades) REFERENCES propiedades (idpropiedades)
 );
-- CREAR LA TABLA estado_reserva
CREATE TABLE estado_reserva (
	idestado_reserva INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
	tipoestado_reserva VARCHAR(45) NOT NULL
    );
-- CREAR LA TABLA reservas
    CREATE TABLE reservas (
        idreservas INT AUTO_INCREMENT NOT NULL,
        fecha_inicio VARCHAR(45) NOT NULL,
        fecha_final VARCHAR(45) NOT NULL,
        fecha_estadoreserva VARCHAR(45) NOT NULL,
        idusuarios INT NOT NULL,
        idestado_reserva INT NOT NULL,
        idpropiedades INT NOT NULL,
        
        PRIMARY KEY (idreservas),
        FOREIGN KEY (idusuarios) REFERENCES usuarios (idusuarios),
        FOREIGN KEY (idestado_reserva) REFERENCES estado_reserva (idestado_reserva),
        FOREIGN KEY (idpropiedades) REFERENCES propiedades (idpropiedades)
    );
-- CREAR LA TABLA estado_pago
CREATE TABLE  estado_pago (
        idestado_pago INT AUTO_INCREMENT NOT NULL PRIMARY KEY,
        tipoestado_pago VARCHAR(45) NOT NULL
    );
-- CREAR LA TABLA pagos

CREATE TABLE pagos (
    idpagos INT AUTO_INCREMENT NOT NULL,
    valor INT NOT NULL,
    fecha_transferencia VARCHAR(45) NOT NULL,
    numero_transferencia INT NOT NULL,
    descripcion VARCHAR(100) NOT NULL,
    idreservas INT NOT NULL,
    idestado_pago INT NOT NULL,

    PRIMARY KEY (idpagos),
    FOREIGN KEY (idreservas) REFERENCES reservas (idreservas),
    FOREIGN KEY (idestado_pago) REFERENCES estado_pago (idestado_pago)
 );
    

SHOW TABLES;
DROP TABLE ubicacion;
SELECT * FROM usuarios;
SELECT * FROM reservas
WHERE idestado_reserva = 1;
SELECT * FROM reservas
WHERE idusuarios = 9;
SELECT * FROM propiedades
WHERE idusuarios = 9;
SELECT * FROM propiedades
WHERE idusuarios = 3;
-- nota para agregar un FK obligatorio toca eliminar los datos de la tabla / agregar una columna 
ALTER TABLE reservas ADD idpropiedades INT NOT NULL;
ALTER TABLE reservas ADD CONSTRAINT fk_propiedadreservada FOREIGN KEY (idpropiedades) REFERENCES propiedades (idpropiedades);
-- listado de proveedores y sus inmuebles 
SELECT * FROM propiedades as p, usuarios as u, roles as r
WHERE r.nombre = 'PROVEEDO' 
AND r.idroles = u.idroles
AND p.idusuarios = u.idusuarios;
-- listado de usuaurios tipo proveedor 
SELECT * FROM  usuarios as u, roles as r
WHERE r.nombre = 'PROVEEDO' 
AND r.idroles = u.idroles;

ALTER TABLE usuarios ADD cedula INT ;

-- Consultar estado reserva
SELECT * FROM estado_reserva;

-- consultar propiedad
SELECT * FROM propiedades;

SELECT * FROM reservas;


-- consulta listdo de pripiedades con estado reservado 
SELECT p.nombre, r.idreservas, r.idestado_reserva, e.tipoestado_reserva
FROM reservas as r, propiedades as p, estado_reserva as e
WHERE e.tipoestado_reserva = 'reservado'
AND e.idestado_reserva = r.idestado_reserva
AND r.idpropiedades = p.idpropiedades;

-- consulta usuarios 
SELECT * FROM usuarios;
-- consulta de las propiedades 
SELECT * FROM propiedades;
-- consulta de insertar propiedades 
INSERT INTO propiedades (nombre, direccion, valor_alojamiento, numero_personas, numero_baños, numero_habitaciones, cocina, aire_acondicionado, piscina, numero_estacionamiento, idusuarios, idtipo_alojamiento, idestado_propiedad, idubicacion)
					VALUES ('las palomas', 'calle 4 n 3 54', 126000, 4, 2, 3,0,1, 1, 3, 1, 2, 1, 2);
-- CONSULTA Tipo_alojamiento 
SELECT * FROM tipo_alojamiento;
SELECT * FROM estado_propiedad;
SELECT * FROM ubicacion;
-- AGREGAR LISTADO DE DEPARTEMENTOS Y MUNICIPIOS DE CUNDINAMARCA
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Albán');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Anolaima');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Chía');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','El Peñón');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Sopó');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Gama');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Sasaima');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Yacopí');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Anapoima');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Arbeláez');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Beltrán');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Bituima');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Bojacá');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Cabrera');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Cachipay');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Cajicá');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Caparrapí');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Caqueza');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Chaguaní');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Chipaque');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Choachí');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Chocontá');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Cogua');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Cota');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Cucunubá');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','El Colegio');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','El Rosal');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Fomeque');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Fosca');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Funza');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Fúquene');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Gachala');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Gachancipá');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Gachetá');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Girardot');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Granada');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Guachetá');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Guaduas');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Guasca');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Guataquí');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Guatavita');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Fusagasugá');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Guayabetal');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Gutiérrez');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Jerusalén');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Junín');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','La Calera');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','La Mesa');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','La Palma');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','La Peña');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','La Vega');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Lenguazaque');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Macheta');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Madrid');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Manta');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Medina');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Mosquera');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Nariño');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Nemocón');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Nilo');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Nimaima');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Nocaima');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Venecia');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Pacho');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Paime');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Pandi');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Paratebueno');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Pasca');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Puerto Salgar');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Pulí');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Quebradanegra');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Quetame');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Quipile');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Apulo');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Ricaurte');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','San Bernardo');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','San Cayetano');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','San Francisco');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Zipaquirá');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Sesquilé');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Sibaté');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Silvania');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Simijaca');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Soacha');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Subachoque');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Suesca');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Supatá');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Susa');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Sutatausa');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Tabio');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Tausa');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Tena');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Tenjo');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Tibacuy');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Tibirita');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Tocaima');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Tocancipá');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Topaipí');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Ubalá');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Ubaque');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Une');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Útica');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Vianí');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Villagómez');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Villapinzón');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Villeta');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Viotá');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Zipacón');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Facatativá');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','San Juan de Río Seco');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Villa de San Diego de Ubate');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Guayabal de Siquima');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','San Antonio del Tequendama');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Agua de Dios');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Carmen de Carupa');
INSERT INTO ubicacion (Departamento, municipio) VALUES ('Cundinamarca','Vergara');


-- ********************************



-- ********************************************    
-- CONSULTAS (CRUD)  roles
-- C: CREATE
    INSERT INTO roles (nombre)
               VALUES ('ADMIN');
    INSERT INTO roles (nombre)
               VALUES ('USER');  
	INSERT INTO roles (nombre)
			   VALUES ('PROVEEDO');
               
-- CONSULTAS (CRUD) tipo_documento
-- C: CREATE
	INSERT INTO tipo_documento (tipo_documento)
				VALUES ('CC');
	INSERT INTO tipo_documento (tipo_documento)
				VALUES ('TI');
	INSERT INTO tipo_documento (tipo_documento)
				VALUES ('CE');
   
-- CONSULTAS (CRUD)  USUARIOS
-- C: CREATE
    INSERT INTO usuarios ( nombres, apellidos, telefono, email, contrasena, idRoles, idtipo_documento) 
                VALUES ('tatiana','gómez','3014671424','tat_gom@hotmail.com','mono', 3,1);   
    INSERT INTO usuarios ( nombres, apellidos, telefono, email, contrasena, idRoles, idtipo_documento) 
                VALUES ('sebastian','castiblanco','3044563245','sebastiancasti@hotmail.com','sebas', 2,1); 
	INSERT INTO usuarios ( nombres, apellidos, telefono, email, contrasena, idRoles, idtipo_documento) 
                VALUES ('pablo','castro','3044565645','pablocastro@hotmail.com','pablo', 3,1); 
	INSERT INTO usuarios ( nombres, apellidos, telefono, email, contrasena, idRoles, idtipo_documento) 
                VALUES ('valentina','vargas','3217648372','valentin@hotmail.com','valentin', 2,1);
	INSERT INTO usuarios ( nombres, apellidos, telefono, email, contrasena, idRoles, idtipo_documento) 
                VALUES ('marcela','rodriguez','3113456789','marcero@hotmail.com','marciano', 2,1);
	INSERT INTO usuarios ( nombres, apellidos, telefono, email, contrasena, idRoles, idtipo_documento) 
                VALUES ('andres','ramirez','3103726352','andresra@hotmail.com','ramirez', 3,1); 
	INSERT INTO usuarios ( nombres, apellidos, telefono, email, contrasena, idRoles, idtipo_documento)  
                VALUES ('paula','garcia','3003726152','paulagaga@hotmail.com','gaga', 2,1); 
	INSERT INTO usuarios ( nombres, apellidos, telefono, email, contrasena, idRoles, idtipo_documento) 
                VALUES ('cristian','novoha','3128493827','crisnova@hotmail.com','nova', 3,1); 
	INSERT INTO usuarios ( nombres, apellidos, telefono, email, contrasena, idRoles, idtipo_documento) 
                VALUES ('julian','arango','3013748273','mjuli@hotmail.com','juliana', 2,1); 
	INSERT INTO usuarios ( nombres, apellidos, telefono, email, contrasena, idRoles, idtipo_documento)  
                VALUES ('cielo','restrepo','3148372645','cielomaria@hotmail.com','maria', 3,1); 
                
-- CONSULTAS (CRUD)  tipo_alojamiento
-- C: CREATE              

	INSERT INTO tipo_alojamiento (tipo_alojamiento)
				VALUES ('apto');
	INSERT INTO tipo_alojamiento (tipo_alojamiento)
				VALUES ('cabana');
	INSERT INTO tipo_alojamiento (tipo_alojamiento)
				VALUES ('finca');
	
-- CONSULTAS (CRUD)  tipoestado_propiedad 
-- C: CREATE              

	INSERT INTO estado_propiedad (tipoestado_propiedad)
				VALUES ('reservado');
	INSERT INTO estado_propiedad (tipoestado_propiedad)
				VALUES ('pendiente');
	INSERT INTO estado_propiedad (tipoestado_propiedad)
				VALUES ('cancelado');
	INSERT INTO estado_propiedad (tipoestado_propiedad)
				VALUES ('disponible');
                
-- CONSULTAS (CRUD)  ubicacion 
-- C: CREATE              

	INSERT INTO ubicacion (Departamento, municipio)
				VALUES ('cundinamarca', 'girardot');
	INSERT INTO ubicacion (Departamento, municipio)
				VALUES ('cundinamarca', 'ricaurte');
	INSERT INTO ubicacion (Departamento, municipio)
				VALUES ('cundinamarca', 'tocaima');
	INSERT INTO ubicacion (Departamento, municipio)
				VALUES ('cundinamarca', 'la vega');
	INSERT INTO ubicacion (Departamento, municipio)
				VALUES ('cundinamarca', 'bogota');
                
	
-- CONSULTAR (CRUD) actividades_adicionales
-- C: CREATE 

	INSERT INTO actividades_adicionales (nombre, idubicacion)
								VALUES ('parapente', 2);
	INSERT INTO actividades_adicionales (nombre, idubicacion)
								VALUES ('caminata ecologica', 3);
	INSERT INTO actividades_adicionales (nombre, idubicacion)
								VALUES ('escalar', 1);
	INSERT INTO actividades_adicionales (nombre, idubicacion)
								VALUES ('cabalgata', 5);
	INSERT INTO actividades_adicionales (nombre, idubicacion)
								VALUES ('termales', 4);
                  
                  
-- CONSULTAR (CRUD) propiedades
-- C: CREATE

	INSERT INTO propiedades (nombre, direccion, valor_alojamiento, numero_personas, numero_baños, numero_habitaciones, cocina, aire_acondicionado, piscina, numero_estacionamiento, idusuarios, idtipo_alojamiento, idestado_propiedad, idubicacion)
					VALUES ('las palomas', 'calle 4 n 3 54', 126000, 4, 2, 3,0,1, 1, 3, 1, 2, 1, 2);
	INSERT INTO propiedades (nombre, direccion, valor_alojamiento, numero_personas,numero_baños, numero_habitaciones, cocina,aire_acondicionado, piscina, numero_estacionamiento, idusuarios, idtipo_alojamiento, idestado_propiedad, idubicacion)
					VALUES ('las margaritas', 'calle 5 n 34 54', 326000, 4, 2, 3,0,1, 1, 3, 3, 1, 4, 3);
	INSERT INTO propiedades (nombre, direccion, valor_alojamiento, numero_personas, numero_baños, numero_habitaciones, cocina,aire_acondicionado, piscina, numero_estacionamiento, idusuarios, idtipo_alojamiento, idestado_propiedad, idubicacion)
					VALUES ('patronas', 'cra 25 n 34 12', 226000, 4, 2, 3,0,1, 1, 3, 6, 1, 4, 3);
	INSERT INTO propiedades (nombre, direccion, valor_alojamiento, numero_personas, numero_baños, numero_habitaciones, cocina,aire_acondicionado, piscina, numero_estacionamiento, idusuarios, idtipo_alojamiento, idestado_propiedad, idubicacion)
					VALUES ('acacias', 'cra 34 n 78 45', 145000, 4, 2, 3,0,1, 1, 3, 8, 3, 1, 2);
	INSERT INTO propiedades (nombre, direccion, valor_alojamiento, numero_personas, numero_baños, numero_habitaciones, cocina,aire_acondicionado, piscina, numero_estacionamiento, idusuarios, idtipo_alojamiento, idestado_propiedad, idubicacion)
					VALUES ('las marias', 'trav 33 n 78 11', 186000, 4, 2, 3,0,1, 1, 3, 10, 2, 1, 4);
	INSERT INTO propiedades (nombre, direccion, valor_alojamiento, numero_personas, numero_baños, numero_habitaciones, cocina,aire_acondicionado, piscina, numero_estacionamiento, idusuarios, idtipo_alojamiento, idestado_propiedad, idubicacion)
					VALUES ('marcianos', 'calle 130 n 12 08', 199000, 4, 2, 3,0,1, 1, 3, 10, 3, 1, 1);
                    
  
-- CONSULTA (CRUD) estado_reserva
-- C: CREATE
	INSERT INTO estado_reserva (tipoestado_reserva)
						VALUES ('reservado');
	INSERT INTO estado_reserva (tipoestado_reserva)
						VALUES ('disponible');
	INSERT INTO estado_reserva (tipoestado_reserva)
						VALUES ('cancelado');
                        
SELECT p.nombre, r.idreservas, r.idestado_reserva, e.tipoestado_reserva
FROM reservas as r, propiedades as p, estado_reserva as e
WHERE e.tipoestado_reserva = 'reservado'
AND e.idestado_reserva = r.idestado_reserva
AND r.idpropiedades = p.idpropiedades;
      -- delete from reservas where idreservas != 0;                  
-- CONSULTA (CRUD) reservas
-- C CREATE 
	INSERT INTO reservas (fecha_inicio, fecha_final, fecha_estadoreserva, idusuarios, idestado_reserva, idpropiedades)
				  VALUES ('12/05/20', '18/05/20', '12/05/20', 2, 1, 1);
	INSERT INTO reservas (fecha_inicio, fecha_final, fecha_estadoreserva, idusuarios, idestado_reserva, idpropiedades)
				  VALUES ('10/05/20', '20/05/20', '10/05/20', 4, 1, 6);
	INSERT INTO reservas (fecha_inicio, fecha_final, fecha_estadoreserva, idusuarios, idestado_reserva, idpropiedades)
				  VALUES ('23/05/20', '25/05/20', '23/05/20', 5, 1, 3);
	INSERT INTO reservas (fecha_inicio, fecha_final, fecha_estadoreserva, idusuarios, idestado_reserva, idpropiedades)
				  VALUES ('24/05/20', '28/05/20', '24/05/20', 7, 1, 2);
	INSERT INTO reservas (fecha_inicio, fecha_final, fecha_estadoreserva, idusuarios, idestado_reserva, idpropiedades)
				  VALUES ('12/05/20', '18/05/20', '12/05/20', 9, 1, 6);
	INSERT INTO reservas (fecha_inicio, fecha_final, fecha_estadoreserva, idusuarios, idestado_reserva, idpropiedades)
				  VALUES ('02/06/20', '08/06/20', '02/06/20', 9, 1, 4);
	INSERT INTO reservas (fecha_inicio, fecha_final, fecha_estadoreserva, idusuarios, idestado_reserva, idpropiedades)
				  VALUES ('10/06/20', '24/06/20', '10/06/20', 2, 2, 4);
	INSERT INTO reservas (fecha_inicio, fecha_final, fecha_estadoreserva, idusuarios, idestado_reserva, idpropiedades)
				  VALUES ('02/06/20', '08/06/20', '02/06/20', 5, 3, 4);
                  
 select * from propiedades;                       
-- CONSULTAR (CRUD) adjuntos
-- C: CREATE 

	INSERT INTO adjuntos (tipo_archivo, ruta_archivo, descripcion, idpropiedades)
								VALUES ('pdf','www.google.com', 'paginaweb', 2);

